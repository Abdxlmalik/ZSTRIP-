"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { CartLine } from "./types";

interface CartState {
  lines: CartLine[];
  isDrawerOpen: boolean;
  addLine: (line: CartLine) => void;
  updateQuantity: (productId: string, size: string, color: string | null, quantity: number) => void;
  removeLine: (productId: string, size: string, color: string | null) => void;
  clear: () => void;
  openDrawer: () => void;
  closeDrawer: () => void;
}

function sameLine(a: CartLine, productId: string, size: string, color: string | null) {
  return a.productId === productId && a.size === size && (a.color ?? null) === color;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      lines: [],
      isDrawerOpen: false,
      addLine: (line) => {
        const existing = get().lines.find((l) => sameLine(l, line.productId, line.size, line.color));
        if (existing) {
          set({
            lines: get().lines.map((l) =>
              sameLine(l, line.productId, line.size, line.color)
                ? { ...l, quantity: Math.min(l.quantity + line.quantity, l.maxStock) }
                : l
            ),
          });
        } else {
          set({ lines: [...get().lines, line] });
        }
        set({ isDrawerOpen: true });
      },
      updateQuantity: (productId, size, color, quantity) => {
        set({
          lines: get()
            .lines.map((l) =>
              sameLine(l, productId, size, color)
                ? { ...l, quantity: Math.max(1, Math.min(quantity, l.maxStock)) }
                : l
            )
            .filter((l) => l.quantity > 0),
        });
      },
      removeLine: (productId, size, color) => {
        set({ lines: get().lines.filter((l) => !sameLine(l, productId, size, color)) });
      },
      clear: () => set({ lines: [] }),
      openDrawer: () => set({ isDrawerOpen: true }),
      closeDrawer: () => set({ isDrawerOpen: false }),
    }),
    {
      name: "zstrip-cart",
      partialize: (state) => ({ lines: state.lines }),
    }
  )
);

export function cartCount(lines: CartLine[]): number {
  return lines.reduce((sum, l) => sum + l.quantity, 0);
}

export function cartSubtotal(lines: CartLine[]): number {
  return lines.reduce((sum, l) => sum + l.price * l.quantity, 0);
}
