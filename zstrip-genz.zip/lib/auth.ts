/**
 * Demo-grade admin auth: a single admin account configured via environment
 * variables (email + bcrypt password hash), with a signed, HTTP-only session
 * cookie. This is intentionally simple for a dev/demo deployment — for a
 * real production store, swap this for a proper auth provider (NextAuth,
 * Clerk, Lucia, etc.) backed by a real user table with rotating sessions.
 *
 * Implemented with Web Crypto (crypto.subtle) rather than Node's `crypto`
 * module so the exact same code can verify sessions inside `middleware.ts`,
 * which runs on the Edge runtime.
 */

export const ADMIN_SESSION_COOKIE = "zstrip_admin_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 8; // 8 hours

interface SessionPayload {
  email: string;
  exp: number;
}

function getSecret(): string {
  const secret = process.env.ADMIN_SESSION_SECRET;
  if (!secret || secret.length < 16) {
    throw new Error(
      "ADMIN_SESSION_SECRET is missing or too short. Set a long random string in your environment."
    );
  }
  return secret;
}

function uint8ToBase64Url(bytes: Uint8Array): string {
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  const base64 = btoa(binary);
  return base64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64UrlToUint8(value: string): Uint8Array {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/").padEnd(
    value.length + ((4 - (value.length % 4)) % 4),
    "="
  );
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function getHmacKey(): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  return crypto.subtle.importKey(
    "raw",
    encoder.encode(getSecret()),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"]
  );
}

export async function createSessionToken(email: string): Promise<string> {
  const payload: SessionPayload = { email, exp: Date.now() + SESSION_TTL_MS };
  const payloadBytes = new TextEncoder().encode(JSON.stringify(payload));
  const payloadB64 = uint8ToBase64Url(payloadBytes);

  const key = await getHmacKey();
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(payloadB64));
  const sigB64 = uint8ToBase64Url(new Uint8Array(signature));

  return `${payloadB64}.${sigB64}`;
}

export async function verifySessionToken(token: string | undefined | null): Promise<string | null> {
  if (!token) return null;
  const [payloadB64, sigB64] = token.split(".");
  if (!payloadB64 || !sigB64) return null;

  try {
    const key = await getHmacKey();
    const valid = await crypto.subtle.verify(
      "HMAC",
      key,
      base64UrlToUint8(sigB64) as unknown as BufferSource,
      new TextEncoder().encode(payloadB64)
    );
    if (!valid) return null;

    const payload: SessionPayload = JSON.parse(
      new TextDecoder().decode(base64UrlToUint8(payloadB64))
    );
    if (payload.exp < Date.now()) return null;
    return payload.email;
  } catch {
    return null;
  }
}

export function getSessionMaxAgeSeconds(): number {
  return SESSION_TTL_MS / 1000;
}
