import type { OrderStatus, ProductDTO } from "./types";

export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

/** Format an integer-paise amount as an INR currency string, e.g. 129900 -> "₹1,299". */
export function formatPrice(paise: number): string {
  const rupees = Math.round(paise) / 100;
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: rupees % 1 === 0 ? 0 : 2,
  }).format(rupees);
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

/** Deterministic, reliable placeholder image URL — never 404s. */
export function imageUrl(seed: string, width = 900, height = 1125): string {
  return `https://picsum.photos/seed/${encodeURIComponent(seed)}/${width}/${height}`;
}

let orderCounter = 0;
export function generateOrderNumber(sequence: number): string {
  const year = new Date().getFullYear();
  return `ZSG-${year}-${String(sequence).padStart(6, "0")}`;
}

export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  PENDING: "Pending",
  CONFIRMED: "Confirmed",
  PROCESSING: "Processing",
  SHIPPED: "Shipped",
  DELIVERED: "Delivered",
  CANCELLED: "Cancelled",
  RETURNED: "Returned",
  REFUNDED: "Refunded",
};

// Tailwind class fragments per status — kept off color alone (labels + icons carry meaning too).
export const ORDER_STATUS_STYLE: Record<OrderStatus, string> = {
  PENDING: "border-line text-muted",
  CONFIRMED: "border-white/40 text-white",
  PROCESSING: "border-white/40 text-white",
  SHIPPED: "border-white/60 text-white",
  DELIVERED: "border-white bg-white text-black",
  CANCELLED: "border-line text-muted line-through",
  RETURNED: "border-line text-muted",
  REFUNDED: "border-line text-muted",
};

export function isPrismaErrorCode(error: unknown, code: string): boolean {
  return (
    typeof error === "object" &&
    error !== null &&
    "code" in error &&
    (error as { code?: unknown }).code === code
  );
}

export function parseJsonArray(value: string | null | undefined): string[] {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((v) => typeof v === "string") : [];
  } catch {
    return [];
  }
}

export function toProductDTO(p: {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  compareAtPrice: number | null;
  images: string;
  category: string;
  sizes: string;
  colors: string;
  stock: number;
  sku: string;
  material: string | null;
  fit: string | null;
  care: string | null;
  featured: boolean;
  isNew: boolean;
  isSale: boolean;
  published: boolean;
  createdAt: Date;
  updatedAt: Date;
}): ProductDTO {
  return {
    ...p,
    images: parseJsonArray(p.images).map((seed) =>
      seed.startsWith("http") ? seed : imageUrl(seed)
    ),
    sizes: parseJsonArray(p.sizes),
    colors: parseJsonArray(p.colors),
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  };
}

export function formatDate(iso: string | Date): string {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(d);
}

export function formatDateTime(iso: string | Date): string {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);
}
