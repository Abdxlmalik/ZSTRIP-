import "server-only";
import { db } from "./db";
import { toProductDTO } from "./utils";
import type { ProductDTO } from "./types";

export const CATEGORIES = ["T-Shirts", "Hoodies", "Shirts", "Pants", "Jackets", "Accessories"] as const;

export interface ProductQuery {
  q?: string;
  category?: string;
  size?: string;
  minPrice?: number;
  maxPrice?: number;
  inStockOnly?: boolean;
  sort?: "featured" | "newest" | "price-asc" | "price-desc" | "name-asc";
}

export async function getProducts(query: ProductQuery = {}): Promise<ProductDTO[]> {
  const products = await db.product.findMany({
    where: {
      published: true,
      ...(query.category ? { category: query.category } : {}),
      ...(query.q
        ? {
            OR: [
              { name: { contains: query.q } },
              { description: { contains: query.q } },
              { category: { contains: query.q } },
            ],
          }
        : {}),
      ...(query.minPrice !== undefined || query.maxPrice !== undefined
        ? {
            price: {
              ...(query.minPrice !== undefined ? { gte: query.minPrice } : {}),
              ...(query.maxPrice !== undefined ? { lte: query.maxPrice } : {}),
            },
          }
        : {}),
      ...(query.inStockOnly ? { stock: { gt: 0 } } : {}),
    },
  });

  let dtos = products.map(toProductDTO);

  if (query.size) {
    dtos = dtos.filter((p) => p.sizes.includes(query.size!));
  }

  switch (query.sort) {
    case "newest":
      dtos.sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt));
      break;
    case "price-asc":
      dtos.sort((a, b) => a.price - b.price);
      break;
    case "price-desc":
      dtos.sort((a, b) => b.price - a.price);
      break;
    case "name-asc":
      dtos.sort((a, b) => a.name.localeCompare(b.name));
      break;
    default:
      dtos.sort((a, b) => Number(b.featured) - Number(a.featured));
  }

  return dtos;
}

export async function getFeaturedProducts(limit = 8): Promise<ProductDTO[]> {
  const products = await db.product.findMany({
    where: { published: true, featured: true },
    take: limit,
    orderBy: { createdAt: "desc" },
  });
  return products.map(toProductDTO);
}

export async function getNewArrivals(limit = 8): Promise<ProductDTO[]> {
  const products = await db.product.findMany({
    where: { published: true, isNew: true },
    take: limit,
    orderBy: { createdAt: "desc" },
  });
  return products.map(toProductDTO);
}

export async function getProductBySlug(slug: string): Promise<ProductDTO | null> {
  const product = await db.product.findUnique({ where: { slug } });
  if (!product || !product.published) return null;
  return toProductDTO(product);
}

export async function getRelatedProducts(category: string, excludeId: string, limit = 4): Promise<ProductDTO[]> {
  const products = await db.product.findMany({
    where: { published: true, category, id: { not: excludeId } },
    take: limit,
  });
  return products.map(toProductDTO);
}
