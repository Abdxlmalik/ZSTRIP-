import "server-only";
import Stripe from "stripe";

// Server-only Stripe client. Never import this file from a "use client" component —
// the "server-only" import above makes the build fail loudly if that ever happens,
// which is what keeps STRIPE_SECRET_KEY out of the browser bundle.
const secretKey = process.env.STRIPE_SECRET_KEY;

if (!secretKey) {
  console.warn(
    "STRIPE_SECRET_KEY is not set. Checkout will fail until it is configured in .env.local."
  );
}

export const stripe = new Stripe(secretKey ?? "sk_test_placeholder", {
  apiVersion: "2024-06-20",
});
