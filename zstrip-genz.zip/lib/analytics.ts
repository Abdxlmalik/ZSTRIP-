import "server-only";
import { db } from "./db";
import type { OrderStatus } from "./types";

const PAID = "PAID";

function startOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
function startOfWeek(d: Date) {
  const x = startOfDay(d);
  const day = x.getDay();
  x.setDate(x.getDate() - day);
  return x;
}
function startOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}

export interface KpiSummary {
  totalRevenue: number;
  ordersCount: number;
  productsCount: number;
  customersCount: number;
  todayRevenue: number;
  weekRevenue: number;
  monthRevenue: number;
  ordersThisMonth: number;
  returnedOrders: number;
  cancelledOrders: number;
  pendingOrders: number;
  averageOrderValue: number;
}

export async function getKpiSummary(): Promise<KpiSummary> {
  const now = new Date();
  const [paidOrders, ordersCount, productsCount, customerRows, statusCounts] = await Promise.all([
    db.order.findMany({
      where: { paymentStatus: PAID },
      select: { total: true, createdAt: true },
    }),
    db.order.count(),
    db.product.count(),
    db.order.findMany({ distinct: ["customerEmail"], select: { customerEmail: true } }),
    db.order.groupBy({ by: ["orderStatus"], _count: { _all: true } }),
  ]);

  const totalRevenue = paidOrders.reduce((s, o) => s + o.total, 0);
  const todayRevenue = paidOrders
    .filter((o) => o.createdAt >= startOfDay(now))
    .reduce((s, o) => s + o.total, 0);
  const weekRevenue = paidOrders
    .filter((o) => o.createdAt >= startOfWeek(now))
    .reduce((s, o) => s + o.total, 0);
  const monthOrders = paidOrders.filter((o) => o.createdAt >= startOfMonth(now));
  const monthRevenue = monthOrders.reduce((s, o) => s + o.total, 0);

  const statusMap = Object.fromEntries(
    statusCounts.map((r) => [r.orderStatus, r._count._all])
  ) as Record<string, number>;

  return {
    totalRevenue,
    ordersCount,
    productsCount,
    customersCount: customerRows.length,
    todayRevenue,
    weekRevenue,
    monthRevenue,
    ordersThisMonth: monthOrders.length,
    returnedOrders: statusMap["RETURNED"] ?? 0,
    cancelledOrders: statusMap["CANCELLED"] ?? 0,
    pendingOrders: statusMap["PENDING"] ?? 0,
    averageOrderValue: paidOrders.length > 0 ? Math.round(totalRevenue / paidOrders.length) : 0,
  };
}

export async function getOrderStatusCounts(): Promise<Record<OrderStatus, number>> {
  const rows = await db.order.groupBy({ by: ["orderStatus"], _count: { _all: true } });
  const base: Record<string, number> = {
    PENDING: 0,
    CONFIRMED: 0,
    PROCESSING: 0,
    SHIPPED: 0,
    DELIVERED: 0,
    CANCELLED: 0,
    RETURNED: 0,
    REFUNDED: 0,
  };
  for (const r of rows) base[r.orderStatus] = r._count._all;
  return base as Record<OrderStatus, number>;
}

export interface RevenuePoint {
  label: string;
  revenue: number;
  orders: number;
}

/** Bucketed revenue series for the last N days, one point per day. */
export async function getRevenueSeries(days: number): Promise<RevenuePoint[]> {
  const since = startOfDay(new Date());
  since.setDate(since.getDate() - (days - 1));

  const orders = await db.order.findMany({
    where: { paymentStatus: PAID, createdAt: { gte: since } },
    select: { total: true, createdAt: true },
  });

  const buckets = new Map<string, RevenuePoint>();
  for (let i = 0; i < days; i++) {
    const d = new Date(since);
    d.setDate(d.getDate() + i);
    const key = d.toISOString().slice(0, 10);
    buckets.set(key, {
      label: d.toLocaleDateString("en-IN", { day: "2-digit", month: "short" }),
      revenue: 0,
      orders: 0,
    });
  }
  for (const o of orders) {
    const key = o.createdAt.toISOString().slice(0, 10);
    const bucket = buckets.get(key);
    if (bucket) {
      bucket.revenue += o.total;
      bucket.orders += 1;
    }
  }
  return Array.from(buckets.values());
}

export interface BestSeller {
  productId: string;
  name: string;
  image: string;
  unitsSold: number;
  revenue: number;
  stock: number;
}

export async function getBestSellers(limit = 5): Promise<BestSeller[]> {
  // Revenue per line is price * quantity, so pull raw items and aggregate in JS
  // rather than relying on groupBy's separate sums.
  const items = await db.orderItem.findMany({
    include: { order: { select: { paymentStatus: true } } },
  });
  const revenueMap = new Map<string, number>();
  const unitsMap = new Map<string, number>();
  for (const item of items) {
    if (item.order.paymentStatus !== PAID) continue;
    revenueMap.set(item.productId, (revenueMap.get(item.productId) ?? 0) + item.price * item.quantity);
    unitsMap.set(item.productId, (unitsMap.get(item.productId) ?? 0) + item.quantity);
  }

  const productIds = Array.from(unitsMap.keys());
  if (productIds.length === 0) return [];

  const products = await db.product.findMany({ where: { id: { in: productIds } } });
  const { parseJsonArray, imageUrl } = await import("./utils");

  const rows: BestSeller[] = products.map((p) => {
    const images = parseJsonArray(p.images);
    return {
      productId: p.id,
      name: p.name,
      image: images[0] ? imageUrl(images[0]) : imageUrl(p.slug),
      unitsSold: unitsMap.get(p.id) ?? 0,
      revenue: revenueMap.get(p.id) ?? 0,
      stock: p.stock,
    };
  });

  return rows.sort((a, b) => b.unitsSold - a.unitsSold).slice(0, limit);
}

export interface LowStockProduct {
  id: string;
  name: string;
  stock: number;
  sku: string;
}

export async function getLowStockProducts(): Promise<LowStockProduct[]> {
  const settings = await db.settings.findUnique({ where: { id: 1 } });
  const threshold = settings?.lowStockThreshold ?? 10;
  const products = await db.product.findMany({
    where: { published: true, stock: { lte: threshold } },
    orderBy: { stock: "asc" },
    select: { id: true, name: true, stock: true, sku: true },
  });
  return products;
}

export async function getReturnRate(): Promise<number> {
  const [returned, completed] = await Promise.all([
    db.order.count({ where: { orderStatus: "RETURNED" } }),
    db.order.count({ where: { orderStatus: { in: ["DELIVERED", "RETURNED", "REFUNDED"] } } }),
  ]);
  if (completed === 0) return 0;
  return Math.round((returned / completed) * 1000) / 10; // one decimal place
}

export async function getRefundSummary() {
  const refunded = await db.order.findMany({
    where: { orderStatus: "REFUNDED" },
    select: { total: true },
  });
  return {
    count: refunded.length,
    amount: refunded.reduce((s, o) => s + o.total, 0),
  };
}
