export type OrderStatus =
  | "PENDING"
  | "CONFIRMED"
  | "PROCESSING"
  | "SHIPPED"
  | "DELIVERED"
  | "CANCELLED"
  | "RETURNED"
  | "REFUNDED";

export const ORDER_STATUSES: OrderStatus[] = [
  "PENDING",
  "CONFIRMED",
  "PROCESSING",
  "SHIPPED",
  "DELIVERED",
  "CANCELLED",
  "RETURNED",
  "REFUNDED",
];

// Forward progression used for the customer-facing tracking timeline.
export const ACTIVE_TIMELINE: OrderStatus[] = [
  "PENDING",
  "CONFIRMED",
  "PROCESSING",
  "SHIPPED",
  "DELIVERED",
];

export const TERMINAL_NEGATIVE: OrderStatus[] = ["CANCELLED", "RETURNED", "REFUNDED"];

export type PaymentStatus = "UNPAID" | "PAID" | "FAILED" | "REFUNDED";

export interface ProductDTO {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number; // paise
  compareAtPrice: number | null;
  images: string[];
  category: string;
  sizes: string[];
  colors: string[];
  stock: number;
  sku: string;
  material: string | null;
  fit: string | null;
  care: string | null;
  featured: boolean;
  isNew: boolean;
  isSale: boolean;
  published: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CartLine {
  productId: string;
  slug: string;
  name: string;
  image: string;
  price: number; // paise, snapshot at add-time (server re-validates at checkout)
  size: string;
  color: string | null;
  quantity: number;
  maxStock: number;
}
