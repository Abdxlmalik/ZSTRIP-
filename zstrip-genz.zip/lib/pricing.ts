/**
 * Shared order-total math used by both the client-rendered cart/checkout
 * pages and the server-side checkout API, so the numbers a customer sees
 * before paying always match what the server actually charges.
 */
export const FREE_SHIPPING_THRESHOLD = 199900; // ₹1,999
export const SHIPPING_FLAT = 9900; // ₹99
export const TAX_RATE = 0.05; // flat 5% demo tax rate

export interface PriceableLine {
  price: number; // paise
  quantity: number;
}

export interface OrderTotals {
  subtotal: number;
  shipping: number;
  tax: number;
  total: number;
}

export function computeOrderTotals(lines: PriceableLine[]): OrderTotals {
  const subtotal = lines.reduce((sum, l) => sum + l.price * l.quantity, 0);
  const shipping = lines.length === 0 || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FLAT;
  const tax = Math.round(subtotal * TAX_RATE);
  const total = subtotal + shipping + tax;
  return { subtotal, shipping, tax, total };
}
