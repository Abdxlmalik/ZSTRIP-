# ZSTRIP Genz — Wear The Next.

A full-stack ecommerce storefront + admin dashboard for a Gen-Z streetwear
brand, built with Next.js 14 (App Router), TypeScript, Tailwind CSS,
Prisma/SQLite, Zustand, Framer Motion, and Stripe Checkout (test mode).

## What's actually implemented

**Customer storefront:** home, product listing with search/filter/sort,
product detail (size/color/qty, gallery), cart (persisted to
`localStorage`), checkout with a real server-validated Stripe Checkout
Session, order confirmation, and an order-tracking/lookup flow.

**Admin dashboard:** signed-cookie login (env-configured credentials +
bcrypt), a dashboard with KPIs and charts computed live from the database
(nothing hardcoded), full product CRUD (create/edit/disable/delete),
order management with a status-history audit trail, an analytics page
with a date-range revenue chart and return/refund stats, and a settings
page.

**Notes on a couple of intentional simplifications**, called out here
instead of quietly glossed over:
- The brief asked for the React Bits `GooeyNav` and `CurvedLoop`
  components "as provided" — but their source was never actually included
  anywhere in the conversation this app was generated from, so the
  navbar's animated pill indicator and the home page's scrolling text
  banner are original components built in the same visual spirit, not a
  copy of that library.
- Admin auth is a single account from environment variables (email +
  bcrypt password hash) with a signed HTTP-only session cookie — enough
  for a real dev/demo deployment, but **swap this for a proper auth
  provider (NextAuth, Clerk, Lucia, etc.) backed by a real user table
  before running this for a real store.**
- "Refunded" is an admin-set order status, not a live call to Stripe's
  refund API. Wire up `stripe.refunds.create` in an admin route if you
  need real refunds.
- Categories are a plain string field on `Product` with a fixed list in
  `lib/products.ts`, not a separate `Category` table.
- The contact form and newsletter signup are UI-only, as the brief
  allowed for the initial version — no email is actually sent.

## Local development

```bash
npm install
cp .env.example .env.local   # then fill in the values below
npx prisma generate
npx prisma db push
npm run db:seed
npm run hash:password -- "yourpassword"   # copy the printed hash into .env.local
npm run dev
```

Open http://localhost:3000. Admin dashboard: http://localhost:3000/admin/login

### Environment variables (`.env.local`)

```bash
DATABASE_URL="file:./dev.db"

STRIPE_SECRET_KEY=sk_test_xxxxxxxxxxxxxxxxxxxxxxxx
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_xxxxxxxxxxxxxxxxxxxxxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxxxxxxxxxxxxxxxxxx

NEXT_PUBLIC_BASE_URL=http://localhost:3000

ADMIN_EMAIL=admin@zstripgenz.example.com
ADMIN_PASSWORD_HASH=$2a$10$...   # from `npm run hash:password -- "yourpassword"`
ADMIN_SESSION_SECRET=some-long-random-string
```

Only ever use Stripe **test** keys (`sk_test_...` / `pk_test_...`) during
development. `STRIPE_SECRET_KEY` is only ever imported by server-only
files (`lib/stripe.ts` is guarded with the `server-only` package) — it
never reaches the browser bundle.

### Stripe webhook (local)

```bash
npm install -g stripe-cli   # or use your OS package manager
stripe login
stripe listen --forward-to localhost:3000/api/stripe/webhook
```

Copy the `whsec_...` value it prints into `STRIPE_WEBHOOK_SECRET` in
`.env.local` and restart `npm run dev`. Use Stripe's test card
`4242 4242 4242 4242`, any future expiry, any CVC.

## Deploying to Vercel

1. Push this project to GitHub.
2. Import the repo into Vercel.
3. Set all the environment variables above in the Vercel project settings
   (use your **production** `NEXT_PUBLIC_BASE_URL`).
4. Swap SQLite for a persistent database: change `datasource db.provider`
   in `prisma/schema.prisma` to `"postgresql"` and point `DATABASE_URL`
   at a hosted Postgres instance (Supabase, Neon, RDS, etc.), then run
   `npx prisma db push` against it.
5. In the Stripe Dashboard, add a webhook endpoint pointing at
   `https://your-domain.com/api/stripe/webhook`, subscribed to
   `checkout.session.completed`, and put its signing secret in
   `STRIPE_WEBHOOK_SECRET` on Vercel.
6. Deploy.

## Project structure

```
app/                customer + admin pages (App Router)
  admin/
    login/          public login page (no dashboard chrome)
    (dashboard)/     everything else under /admin — protected by middleware.ts
  api/               route handlers (checkout, orders, admin CRUD, stripe webhook)
components/          shared UI + admin UI
lib/                 db client, auth, stripe, pricing, analytics, product queries, types
prisma/              schema + seed script
data/products.json   seed product catalog (12 products)
```

## Security notes

- Product prices are **never** trusted from the client — `/api/checkout`
  re-reads every price and stock count from the database before creating
  the Stripe session.
- The Stripe webhook verifies the `stripe-signature` header before
  trusting any payload.
- `/admin/*` pages and `/api/admin/*` routes are protected by
  `middleware.ts`, which checks a signed, HTTP-only session cookie —
  typing the URL directly does not get a customer in.
- Order lookup (`/order`) requires both the order number *and* the email
  it was placed under, since order numbers are sequential and guessable
  on their own.
