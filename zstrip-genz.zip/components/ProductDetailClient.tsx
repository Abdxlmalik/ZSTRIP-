"use client";

import { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";
import { formatPrice, cn } from "@/lib/utils";
import { useCartStore } from "@/lib/cart-store";
import QuantitySelector from "./QuantitySelector";
import type { ProductDTO } from "@/lib/types";

export default function ProductDetailClient({ product }: { product: ProductDTO }) {
  const router = useRouter();
  const addLine = useCartStore((s) => s.addLine);
  const [activeImage, setActiveImage] = useState(0);
  const [size, setSize] = useState(product.sizes[0] ?? "");
  const [color, setColor] = useState(product.colors[0] ?? null);
  const [quantity, setQuantity] = useState(1);
  const outOfStock = product.stock <= 0;

  function addToCart() {
    if (!size) {
      toast.error("Select a size first.");
      return;
    }
    addLine({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image: product.images[0],
      price: product.price,
      size,
      color,
      quantity,
      maxStock: product.stock,
    });
    toast.success("Added to cart");
  }

  function buyNow() {
    if (!size) {
      toast.error("Select a size first.");
      return;
    }
    addLine({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image: product.images[0],
      price: product.price,
      size,
      color,
      quantity,
      maxStock: product.stock,
    });
    router.push("/checkout");
  }

  return (
    <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
      {/* GALLERY */}
      <div>
        <div className="relative aspect-[4/5] overflow-hidden rounded-xl bg-surface">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeImage}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="absolute inset-0"
            >
              <Image
                src={product.images[activeImage]}
                alt={`${product.name} — view ${activeImage + 1}`}
                fill
                priority
                sizes="(min-width: 1024px) 45vw, 100vw"
                className="object-cover"
              />
            </motion.div>
          </AnimatePresence>
        </div>
        {product.images.length > 1 && (
          <div className="mt-3 flex gap-3">
            {product.images.map((img, i) => (
              <button
                key={img + i}
                onClick={() => setActiveImage(i)}
                aria-label={`View image ${i + 1}`}
                className={cn(
                  "relative h-20 w-16 overflow-hidden rounded-lg border transition-colors",
                  activeImage === i ? "border-white" : "border-line"
                )}
              >
                <Image src={img} alt="" fill sizes="64px" className="object-cover" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* DETAILS */}
      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-muted">{product.category}</p>
        <h1 className="mt-2 text-3xl font-extrabold tracking-tightest sm:text-4xl">{product.name}</h1>

        <div className="mt-4 flex items-center gap-3">
          <span className="text-2xl font-bold">{formatPrice(product.price)}</span>
          {product.compareAtPrice && (
            <span className="text-base text-muted line-through">{formatPrice(product.compareAtPrice)}</span>
          )}
        </div>

        <p className="mt-5 text-sm leading-relaxed text-muted">{product.description}</p>

        {/* Size */}
        {product.sizes.length > 0 && (
          <div className="mt-8">
            <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-white">Size</p>
            <div className="flex flex-wrap gap-2">
              {product.sizes.map((s) => (
                <button
                  key={s}
                  onClick={() => setSize(s)}
                  className={cn(
                    "min-w-11 rounded-lg border px-3 py-2 text-sm font-medium transition-colors",
                    size === s ? "border-white bg-white text-black" : "border-line text-white hover:border-white"
                  )}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Color */}
        {product.colors.length > 0 && (
          <div className="mt-6">
            <p className="mb-3 text-xs font-semibold uppercase tracking-wide text-white">Color</p>
            <div className="flex flex-wrap gap-2">
              {product.colors.map((c) => (
                <button
                  key={c}
                  onClick={() => setColor(c)}
                  className={cn(
                    "rounded-lg border px-3 py-2 text-sm font-medium transition-colors",
                    color === c ? "border-white bg-white text-black" : "border-line text-white hover:border-white"
                  )}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Quantity + stock */}
        <div className="mt-6 flex items-center gap-4">
          <p className="text-xs font-semibold uppercase tracking-wide text-white">Quantity</p>
          <QuantitySelector value={quantity} onChange={setQuantity} max={Math.max(product.stock, 1)} />
        </div>
        <p className="mt-2 text-xs text-muted">
          {outOfStock ? "Out of stock" : product.stock <= 10 ? `Only ${product.stock} left` : "In stock"}
        </p>

        {/* Actions */}
        <div className="mt-8 flex flex-col gap-3 sm:flex-row">
          <button
            onClick={addToCart}
            disabled={outOfStock}
            className="flex-1 rounded-full border border-white py-3.5 text-sm font-bold uppercase tracking-wide text-white transition-colors hover:bg-white hover:text-black disabled:cursor-not-allowed disabled:opacity-40"
          >
            Add to Cart
          </button>
          <button
            onClick={buyNow}
            disabled={outOfStock}
            className="flex-1 rounded-full bg-white py-3.5 text-sm font-bold uppercase tracking-wide text-black transition-transform hover:scale-[1.02] active:scale-95 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Buy Now
          </button>
        </div>

        {/* Details accordion-ish list */}
        <dl className="mt-10 space-y-4 border-t border-line pt-6 text-sm">
          {product.material && (
            <div className="flex justify-between gap-4">
              <dt className="text-muted">Material</dt>
              <dd className="text-right text-white">{product.material}</dd>
            </div>
          )}
          {product.fit && (
            <div className="flex justify-between gap-4">
              <dt className="text-muted">Fit</dt>
              <dd className="text-right text-white">{product.fit}</dd>
            </div>
          )}
          {product.care && (
            <div className="flex justify-between gap-4">
              <dt className="text-muted">Care</dt>
              <dd className="text-right text-white">{product.care}</dd>
            </div>
          )}
          <div className="flex justify-between gap-4">
            <dt className="text-muted">Shipping</dt>
            <dd className="text-right text-white">Dispatched in 2–4 business days.</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-muted">Returns</dt>
            <dd className="text-right text-white">7-day returns on unworn items.</dd>
          </div>
        </dl>
      </div>
    </div>
  );
}
