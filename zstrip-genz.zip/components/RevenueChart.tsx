"use client";

import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { RevenuePoint } from "@/lib/analytics";
import { formatPrice } from "@/lib/utils";

export default function RevenueChart({ data }: { data: RevenuePoint[] }) {
  return (
    <div className="h-72 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 8, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="revenueFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#ffffff" stopOpacity={0.35} />
              <stop offset="100%" stopColor="#ffffff" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#27272A" vertical={false} />
          <XAxis
            dataKey="label"
            stroke="#A1A1AA"
            fontSize={11}
            tickLine={false}
            axisLine={{ stroke: "#27272A" }}
            interval="preserveStartEnd"
          />
          <YAxis
            stroke="#A1A1AA"
            fontSize={11}
            tickLine={false}
            axisLine={false}
            tickFormatter={(v) => formatPrice(v).replace(".00", "")}
            width={64}
          />
          <Tooltip
            contentStyle={{ background: "#0A0A0A", border: "1px solid #27272A", borderRadius: 8 }}
            labelStyle={{ color: "#FFFFFF" }}
            formatter={(value: number, name: string) =>
              name === "revenue" ? [formatPrice(value), "Revenue"] : [value, "Orders"]
            }
          />
          <Area type="monotone" dataKey="revenue" stroke="#FFFFFF" strokeWidth={2} fill="url(#revenueFill)" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
