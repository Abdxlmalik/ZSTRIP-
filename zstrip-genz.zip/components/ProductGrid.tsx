"use client";

import { motion, useReducedMotion } from "framer-motion";
import ProductCard from "./ProductCard";
import type { ProductDTO } from "@/lib/types";

export default function ProductGrid({ products }: { products: ProductDTO[] }) {
  const reduce = useReducedMotion();

  if (products.length === 0) {
    return (
      <div className="rounded-xl border border-line bg-surface px-6 py-16 text-center">
        <p className="text-lg font-semibold text-white">No products match those filters.</p>
        <p className="mt-2 text-sm text-muted">Try clearing a filter or searching something else.</p>
      </div>
    );
  }

  return (
    <motion.div
      initial="hidden"
      animate="show"
      variants={{
        hidden: {},
        show: { transition: { staggerChildren: reduce ? 0 : 0.05 } },
      }}
      className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
    >
      {products.map((product) => (
        <motion.div
          key={product.id}
          variants={{
            hidden: reduce ? {} : { opacity: 0, y: 16 },
            show: { opacity: 1, y: 0 },
          }}
          transition={{ duration: 0.4 }}
        >
          <ProductCard product={product} />
        </motion.div>
      ))}
    </motion.div>
  );
}
