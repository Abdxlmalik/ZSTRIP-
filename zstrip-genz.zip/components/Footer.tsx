"use client";

import Link from "next/link";
import { useState } from "react";
import { toast } from "sonner";

const SHOP_LINKS = [
  { href: "/products", label: "Shop All" },
  { href: "/products?sort=newest", label: "New Arrivals" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

const HELP_LINKS = [
  { href: "/contact", label: "Shipping" },
  { href: "/contact", label: "Returns" },
  { href: "/contact", label: "Privacy" },
  { href: "/contact", label: "Terms" },
];

export default function Footer() {
  const [email, setEmail] = useState("");

  function handleSubscribe(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim()) return;
    toast.success("You're on the list.");
    setEmail("");
  }

  return (
    <footer className="border-t border-line bg-black">
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <p className="text-2xl font-extrabold tracking-tightest">ZSTRIP GENZ</p>
            <p className="mt-2 text-sm text-muted">WEAR THE NEXT.</p>
            <div className="mt-6 flex gap-3 text-sm text-muted">
              <a href="#" className="rounded-full border border-line px-3 py-1.5 hover:text-white hover:border-white transition-colors">
                Instagram
              </a>
              <a href="#" className="rounded-full border border-line px-3 py-1.5 hover:text-white hover:border-white transition-colors">
                TikTok
              </a>
            </div>
          </div>

          <div>
            <p className="text-sm font-semibold text-white">Shop</p>
            <ul className="mt-4 space-y-3 text-sm text-muted">
              {SHOP_LINKS.map((l) => (
                <li key={l.label}>
                  <Link href={l.href} className="hover:text-white transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-sm font-semibold text-white">Support</p>
            <ul className="mt-4 space-y-3 text-sm text-muted">
              {HELP_LINKS.map((l, i) => (
                <li key={l.label + i}>
                  <Link href={l.href} className="hover:text-white transition-colors">
                    {l.label}
                  </Link>
                </li>
              ))}
              <li>
                <Link href="/order" className="hover:text-white transition-colors">
                  Track Order
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <p className="text-sm font-semibold text-white">Stay in the loop</p>
            <p className="mt-4 text-sm text-muted">Drops, restocks, and nothing else.</p>
            <form onSubmit={handleSubscribe} className="mt-4 flex gap-2">
              <label htmlFor="newsletter-email" className="sr-only">
                Email address
              </label>
              <input
                id="newsletter-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="w-full rounded-full border border-line bg-surface px-4 py-2 text-sm text-white placeholder:text-muted focus:border-white"
              />
              <button
                type="submit"
                className="shrink-0 rounded-full bg-white px-4 py-2 text-sm font-semibold text-black transition-transform hover:scale-[1.03] active:scale-95"
              >
                Join
              </button>
            </form>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-2 border-t border-line pt-6 text-xs text-muted sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} ZSTRIP Genz. All rights reserved.</p>
          <p>Payments processed securely via Stripe (test mode).</p>
        </div>
      </div>
    </footer>
  );
}
