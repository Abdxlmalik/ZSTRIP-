import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface AnalyticsCardProps {
  label: string;
  value: string;
  subtext?: string;
  icon?: LucideIcon;
  accent?: boolean;
}

export default function AnalyticsCard({ label, value, subtext, icon: Icon, accent }: AnalyticsCardProps) {
  return (
    <div
      className={cn(
        "rounded-xl border border-line p-5",
        accent ? "bg-white text-black" : "bg-surface text-white"
      )}
    >
      <div className="flex items-center justify-between">
        <p className={cn("text-xs font-semibold uppercase tracking-wide", accent ? "text-black/60" : "text-muted")}>
          {label}
        </p>
        {Icon && <Icon className={cn("h-4 w-4", accent ? "text-black/60" : "text-muted")} aria-hidden />}
      </div>
      <p className="mt-3 text-2xl font-extrabold tracking-tightest">{value}</p>
      {subtext && (
        <p className={cn("mt-1 text-xs", accent ? "text-black/60" : "text-muted")}>{subtext}</p>
      )}
    </div>
  );
}
