import Link from "next/link";
import { formatDate, formatPrice, cn } from "@/lib/utils";
import type { OrderStatus } from "@/lib/types";
import OrderStatusBadge from "./OrderStatusBadge";

export interface AdminOrderRow {
  id: string;
  orderNumber: string;
  customerName: string;
  customerEmail: string;
  createdAt: string;
  total: number;
  paymentStatus: string;
  orderStatus: string;
  items: { quantity: number }[];
}

export default function AdminOrderTable({ orders }: { orders: AdminOrderRow[] }) {
  if (orders.length === 0) {
    return (
      <div className="rounded-xl border border-line px-4 py-10 text-center text-sm text-muted">
        No orders match those filters.
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-xl border border-line thin-scroll">
      <table className="w-full min-w-[860px] text-left text-sm">
        <thead className="border-b border-line bg-surface text-xs uppercase tracking-wide text-muted">
          <tr>
            <th className="px-4 py-3 font-medium">Order ID</th>
            <th className="px-4 py-3 font-medium">Customer</th>
            <th className="px-4 py-3 font-medium">Date</th>
            <th className="px-4 py-3 font-medium">Items</th>
            <th className="px-4 py-3 font-medium">Total</th>
            <th className="px-4 py-3 font-medium">Payment</th>
            <th className="px-4 py-3 font-medium">Status</th>
            <th className="px-4 py-3 font-medium text-right">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-line">
          {orders.map((order) => (
            <tr key={order.id} className="hover:bg-surface/60">
              <td className="px-4 py-3 font-medium text-white">{order.orderNumber}</td>
              <td className="px-4 py-3">
                <p className="text-white">{order.customerName}</p>
                <p className="text-xs text-muted">{order.customerEmail}</p>
              </td>
              <td className="px-4 py-3 text-muted">{formatDate(order.createdAt)}</td>
              <td className="px-4 py-3 text-muted">
                {order.items.reduce((s, i) => s + i.quantity, 0)} items
              </td>
              <td className="px-4 py-3 font-medium text-white">{formatPrice(order.total)}</td>
              <td className="px-4 py-3">
                <span
                  className={cn(
                    "rounded-full px-2.5 py-1 text-xs font-semibold",
                    order.paymentStatus === "PAID" ? "bg-white text-black" : "border border-line text-muted"
                  )}
                >
                  {order.paymentStatus}
                </span>
              </td>
              <td className="px-4 py-3">
                <OrderStatusBadge status={order.orderStatus as OrderStatus} />
              </td>
              <td className="px-4 py-3 text-right">
                <Link
                  href={`/admin/orders/${order.id}`}
                  className="rounded-full border border-line px-3 py-1.5 text-xs font-semibold text-white hover:border-white"
                >
                  View
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
