"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { LogOut } from "lucide-react";

interface SettingsData {
  storeName: string;
  currency: string;
  lowStockThreshold: number;
  storeEmail: string;
}

const inputClass =
  "w-full rounded-lg border border-line bg-black px-3.5 py-2.5 text-sm text-white placeholder:text-muted focus:border-white";
const labelClass = "mb-1.5 block text-xs font-medium text-muted";

export default function AdminSettingsForm({ initial }: { initial: SettingsData }) {
  const router = useRouter();
  const [form, setForm] = useState(initial);
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? "Failed to save settings.");
        return;
      }
      toast.success("Settings saved");
    } catch {
      toast.error("Something went wrong saving settings.");
    } finally {
      setSaving(false);
    }
  }

  async function handleLogout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <div className="max-w-xl space-y-8">
      <form onSubmit={handleSubmit} className="space-y-5 rounded-xl border border-line bg-surface p-6">
        <div>
          <label htmlFor="storeName" className={labelClass}>
            Store Name
          </label>
          <input
            id="storeName"
            value={form.storeName}
            onChange={(e) => setForm((f) => ({ ...f, storeName: e.target.value }))}
            className={inputClass}
          />
        </div>
        <div className="grid gap-5 sm:grid-cols-2">
          <div>
            <label htmlFor="currency" className={labelClass}>
              Currency
            </label>
            <input
              id="currency"
              value={form.currency}
              onChange={(e) => setForm((f) => ({ ...f, currency: e.target.value }))}
              className={inputClass}
            />
          </div>
          <div>
            <label htmlFor="lowStockThreshold" className={labelClass}>
              Low Stock Threshold
            </label>
            <input
              id="lowStockThreshold"
              type="number"
              min="0"
              value={form.lowStockThreshold}
              onChange={(e) => setForm((f) => ({ ...f, lowStockThreshold: Number(e.target.value) }))}
              className={inputClass}
            />
          </div>
        </div>
        <div>
          <label htmlFor="storeEmail" className={labelClass}>
            Store Email
          </label>
          <input
            id="storeEmail"
            type="email"
            value={form.storeEmail}
            onChange={(e) => setForm((f) => ({ ...f, storeEmail: e.target.value }))}
            className={inputClass}
          />
        </div>
        <button
          type="submit"
          disabled={saving}
          className="rounded-full bg-white px-6 py-3 text-sm font-bold uppercase tracking-wide text-black disabled:opacity-60"
        >
          {saving ? "Saving..." : "Save Settings"}
        </button>
      </form>

      <div className="rounded-xl border border-line bg-surface p-6">
        <p className="text-xs font-semibold uppercase tracking-wide text-muted">Admin Profile</p>
        <p className="mt-2 text-sm text-white">Admin</p>
        <button
          onClick={handleLogout}
          className="mt-4 flex items-center gap-2 rounded-full border border-line px-4 py-2 text-sm font-medium text-white hover:border-white"
        >
          <LogOut className="h-4 w-4" aria-hidden />
          Logout
        </button>
      </div>
    </div>
  );
}
