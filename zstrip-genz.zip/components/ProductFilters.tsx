"use client";

import { useRouter, usePathname, useSearchParams } from "next/navigation";
import { cn } from "@/lib/utils";

const PRICE_RANGES = [
  { label: "Under ₹1,000", min: 0, max: 99900 },
  { label: "₹1,000 – ₹2,000", min: 100000, max: 199900 },
  { label: "₹2,000 – ₹3,500", min: 200000, max: 349900 },
  { label: "Over ₹3,500", min: 350000, max: undefined },
];

interface ProductFiltersProps {
  categories: readonly string[];
  sizes: string[];
}

export default function ProductFilters({ categories, sizes }: ProductFiltersProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const activeCategory = searchParams.get("category") ?? "";
  const activeSize = searchParams.get("size") ?? "";
  const activeMin = searchParams.get("minPrice");
  const activeMax = searchParams.get("maxPrice");
  const inStockOnly = searchParams.get("inStock") === "1";

  function setParam(key: string, value: string | null) {
    const params = new URLSearchParams(searchParams.toString());
    if (value) params.set(key, value);
    else params.delete(key);
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  }

  function togglePriceRange(min: number, max: number | undefined) {
    const isActive = activeMin === String(min) && activeMax === String(max ?? "");
    const params = new URLSearchParams(searchParams.toString());
    if (isActive) {
      params.delete("minPrice");
      params.delete("maxPrice");
    } else {
      params.set("minPrice", String(min));
      if (max !== undefined) params.set("maxPrice", String(max));
      else params.delete("maxPrice");
    }
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  }

  function clearAll() {
    router.push(pathname, { scroll: false });
  }

  const hasActiveFilters = activeCategory || activeSize || activeMin || inStockOnly;

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-bold uppercase tracking-wide text-white">Filters</h2>
        {hasActiveFilters && (
          <button onClick={clearAll} className="text-xs font-medium text-muted underline hover:text-white">
            Clear all
          </button>
        )}
      </div>

      <fieldset>
        <legend className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted">Category</legend>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setParam("category", null)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
              !activeCategory ? "border-white bg-white text-black" : "border-line text-muted hover:text-white"
            )}
          >
            All
          </button>
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setParam("category", activeCategory === category ? null : category)}
              className={cn(
                "rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
                activeCategory === category
                  ? "border-white bg-white text-black"
                  : "border-line text-muted hover:text-white"
              )}
            >
              {category}
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted">Price</legend>
        <div className="flex flex-col gap-2">
          {PRICE_RANGES.map((range) => {
            const active = activeMin === String(range.min) && activeMax === String(range.max ?? "");
            return (
              <button
                key={range.label}
                onClick={() => togglePriceRange(range.min, range.max)}
                className={cn(
                  "rounded-lg border px-3 py-2 text-left text-xs font-medium transition-colors",
                  active ? "border-white bg-white text-black" : "border-line text-muted hover:text-white"
                )}
              >
                {range.label}
              </button>
            );
          })}
        </div>
      </fieldset>

      {sizes.length > 0 && (
        <fieldset>
          <legend className="mb-3 text-xs font-semibold uppercase tracking-wide text-muted">Size</legend>
          <div className="flex flex-wrap gap-2">
            {sizes.map((size) => (
              <button
                key={size}
                onClick={() => setParam("size", activeSize === size ? null : size)}
                className={cn(
                  "min-w-10 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors",
                  activeSize === size ? "border-white bg-white text-black" : "border-line text-muted hover:text-white"
                )}
              >
                {size}
              </button>
            ))}
          </div>
        </fieldset>
      )}

      <fieldset>
        <label className="flex items-center gap-2 text-xs font-medium text-white">
          <input
            type="checkbox"
            checked={inStockOnly}
            onChange={(e) => setParam("inStock", e.target.checked ? "1" : null)}
            className="h-4 w-4 rounded border-line bg-surface accent-white"
          />
          In stock only
        </label>
      </fieldset>
    </div>
  );
}
