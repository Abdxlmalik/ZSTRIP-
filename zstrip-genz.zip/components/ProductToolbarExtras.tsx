"use client";

import { useState } from "react";
import { useRouter, usePathname, useSearchParams } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { SlidersHorizontal, X } from "lucide-react";
import ProductFilters from "./ProductFilters";

const SORT_OPTIONS = [
  { value: "featured", label: "Featured" },
  { value: "newest", label: "Newest" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "name-asc", label: "Name A-Z" },
];

export function SortSelect() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const value = searchParams.get("sort") ?? "featured";

  function onChange(next: string) {
    const params = new URLSearchParams(searchParams.toString());
    params.set("sort", next);
    router.push(`${pathname}?${params.toString()}`, { scroll: false });
  }

  return (
    <label className="flex items-center gap-2 text-sm">
      <span className="hidden text-muted sm:inline">Sort</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="rounded-full border border-line bg-surface px-3 py-2 text-sm text-white focus:border-white"
        aria-label="Sort products"
      >
        {SORT_OPTIONS.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </label>
  );
}

export function MobileFilterDrawer({
  categories,
  sizes,
}: {
  categories: readonly string[];
  sizes: string[];
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="lg:hidden">
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 rounded-full border border-line px-4 py-2 text-sm font-medium text-white"
      >
        <SlidersHorizontal className="h-4 w-4" aria-hidden />
        Filters
      </button>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              className="fixed inset-0 z-[90] bg-black/70"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
            />
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-label="Filter products"
              className="fixed inset-x-0 bottom-0 z-[91] max-h-[85vh] overflow-y-auto rounded-t-2xl border-t border-line bg-black p-6 thin-scroll"
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              transition={{ type: "tween", duration: 0.25 }}
            >
              <div className="mb-4 flex items-center justify-between">
                <p className="text-sm font-bold uppercase tracking-wide">Filter &amp; Sort</p>
                <button onClick={() => setOpen(false)} aria-label="Close filters">
                  <X className="h-5 w-5" aria-hidden />
                </button>
              </div>
              <ProductFilters categories={categories} sizes={sizes} />
              <button
                onClick={() => setOpen(false)}
                className="mt-8 w-full rounded-full bg-white py-3 text-sm font-bold text-black"
              >
                Show Results
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
