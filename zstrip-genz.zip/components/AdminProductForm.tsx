"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { CATEGORIES } from "@/lib/products";
import { slugify } from "@/lib/utils";
import type { ProductDTO } from "@/lib/types";

interface AdminProductFormProps {
  product?: ProductDTO;
}

interface FormState {
  name: string;
  slug: string;
  description: string;
  price: string; // rupees, as text input
  compareAtPrice: string;
  category: string;
  images: string; // comma separated
  sizes: string; // comma separated
  colors: string; // comma separated
  stock: string;
  sku: string;
  material: string;
  fit: string;
  care: string;
  featured: boolean;
  isNew: boolean;
  isSale: boolean;
  published: boolean;
}

function toFormState(product?: ProductDTO): FormState {
  if (!product) {
    return {
      name: "",
      slug: "",
      description: "",
      price: "",
      compareAtPrice: "",
      category: CATEGORIES[0],
      images: "",
      sizes: "S, M, L, XL",
      colors: "",
      stock: "0",
      sku: "",
      material: "",
      fit: "",
      care: "",
      featured: false,
      isNew: true,
      isSale: false,
      published: true,
    };
  }
  return {
    name: product.name,
    slug: product.slug,
    description: product.description,
    price: String(product.price / 100),
    compareAtPrice: product.compareAtPrice ? String(product.compareAtPrice / 100) : "",
    category: product.category,
    // Images come back as full picsum/remote URLs — extract the seed for re-editing where possible.
    images: product.images
      .map((url) => {
        const match = url.match(/\/seed\/([^/]+)\//);
        return match ? decodeURIComponent(match[1]) : url;
      })
      .join(", "),
    sizes: product.sizes.join(", "),
    colors: product.colors.join(", "),
    stock: String(product.stock),
    sku: product.sku,
    material: product.material ?? "",
    fit: product.fit ?? "",
    care: product.care ?? "",
    featured: product.featured,
    isNew: product.isNew,
    isSale: product.isSale,
    published: product.published,
  };
}

const inputClass =
  "w-full rounded-lg border border-line bg-black px-3.5 py-2.5 text-sm text-white placeholder:text-muted focus:border-white";
const labelClass = "mb-1.5 block text-xs font-medium text-muted";

export default function AdminProductForm({ product }: AdminProductFormProps) {
  const router = useRouter();
  const isEdit = Boolean(product);
  const [form, setForm] = useState<FormState>(toFormState(product));
  const [saving, setSaving] = useState(false);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function splitList(value: string): string[] {
    return value
      .split(",")
      .map((v) => v.trim())
      .filter(Boolean);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const priceNum = Math.round(parseFloat(form.price) * 100);
    if (Number.isNaN(priceNum) || priceNum < 0) {
      toast.error("Enter a valid price.");
      return;
    }
    const images = splitList(form.images);
    if (images.length === 0) {
      toast.error("Add at least one image.");
      return;
    }

    setSaving(true);
    const payload = {
      name: form.name,
      slug: form.slug ? slugify(form.slug) : slugify(form.name),
      description: form.description,
      price: priceNum,
      compareAtPrice: form.compareAtPrice ? Math.round(parseFloat(form.compareAtPrice) * 100) : null,
      images,
      category: form.category,
      sizes: splitList(form.sizes),
      colors: splitList(form.colors),
      stock: Number(form.stock) || 0,
      sku: form.sku,
      material: form.material || null,
      fit: form.fit || null,
      care: form.care || null,
      featured: form.featured,
      isNew: form.isNew,
      isSale: form.isSale,
      published: form.published,
    };

    try {
      const res = await fetch(isEdit ? `/api/admin/products/${product!.id}` : "/api/admin/products", {
        method: isEdit ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? "Failed to save product.");
        setSaving(false);
        return;
      }
      toast.success(isEdit ? "Product updated" : "Product created");
      router.push("/admin/products");
      router.refresh();
    } catch {
      toast.error("Something went wrong saving the product.");
      setSaving(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="grid gap-6 rounded-xl border border-line bg-surface p-6 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label htmlFor="name" className={labelClass}>
            Product Name *
          </label>
          <input
            id="name"
            required
            value={form.name}
            onChange={(e) => update("name", e.target.value)}
            className={inputClass}
          />
        </div>
        <div>
          <label htmlFor="slug" className={labelClass}>
            Slug (auto-generated if left blank)
          </label>
          <input
            id="slug"
            value={form.slug}
            placeholder={form.name ? slugify(form.name) : "product-slug"}
            onChange={(e) => update("slug", e.target.value)}
            className={inputClass}
          />
        </div>
        <div>
          <label htmlFor="sku" className={labelClass}>
            SKU *
          </label>
          <input id="sku" required value={form.sku} onChange={(e) => update("sku", e.target.value)} className={inputClass} />
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="description" className={labelClass}>
            Description *
          </label>
          <textarea
            id="description"
            required
            rows={4}
            value={form.description}
            onChange={(e) => update("description", e.target.value)}
            className={inputClass}
          />
        </div>

        <div>
          <label htmlFor="price" className={labelClass}>
            Price (₹) *
          </label>
          <input
            id="price"
            required
            type="number"
            min="0"
            step="0.01"
            value={form.price}
            onChange={(e) => update("price", e.target.value)}
            className={inputClass}
          />
        </div>
        <div>
          <label htmlFor="compareAtPrice" className={labelClass}>
            Compare-at Price (₹)
          </label>
          <input
            id="compareAtPrice"
            type="number"
            min="0"
            step="0.01"
            value={form.compareAtPrice}
            onChange={(e) => update("compareAtPrice", e.target.value)}
            className={inputClass}
          />
        </div>

        <div>
          <label htmlFor="category" className={labelClass}>
            Category *
          </label>
          <select
            id="category"
            value={form.category}
            onChange={(e) => update("category", e.target.value)}
            className={inputClass}
          >
            {CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="stock" className={labelClass}>
            Stock Quantity *
          </label>
          <input
            id="stock"
            required
            type="number"
            min="0"
            value={form.stock}
            onChange={(e) => update("stock", e.target.value)}
            className={inputClass}
          />
        </div>

        <div className="sm:col-span-2">
          <label htmlFor="images" className={labelClass}>
            Images — comma separated (picsum seed names or full image URLs) *
          </label>
          <input
            id="images"
            required
            value={form.images}
            placeholder="zstrip-tee-core-1, zstrip-tee-core-2"
            onChange={(e) => update("images", e.target.value)}
            className={inputClass}
          />
        </div>
        <div>
          <label htmlFor="sizes" className={labelClass}>
            Sizes — comma separated
          </label>
          <input id="sizes" value={form.sizes} onChange={(e) => update("sizes", e.target.value)} className={inputClass} />
        </div>
        <div>
          <label htmlFor="colors" className={labelClass}>
            Colors — comma separated
          </label>
          <input id="colors" value={form.colors} onChange={(e) => update("colors", e.target.value)} className={inputClass} />
        </div>

        <div>
          <label htmlFor="material" className={labelClass}>
            Material
          </label>
          <input id="material" value={form.material} onChange={(e) => update("material", e.target.value)} className={inputClass} />
        </div>
        <div>
          <label htmlFor="fit" className={labelClass}>
            Fit
          </label>
          <input id="fit" value={form.fit} onChange={(e) => update("fit", e.target.value)} className={inputClass} />
        </div>
        <div className="sm:col-span-2">
          <label htmlFor="care" className={labelClass}>
            Care Instructions
          </label>
          <input id="care" value={form.care} onChange={(e) => update("care", e.target.value)} className={inputClass} />
        </div>
      </div>

      <div className="flex flex-wrap gap-6 rounded-xl border border-line bg-surface p-6">
        {(
          [
            ["featured", "Featured"],
            ["isNew", "New Arrival"],
            ["isSale", "On Sale"],
            ["published", "Published"],
          ] as const
        ).map(([key, label]) => (
          <label key={key} className="flex items-center gap-2 text-sm text-white">
            <input
              type="checkbox"
              checked={form[key]}
              onChange={(e) => update(key, e.target.checked)}
              className="h-4 w-4 rounded border-line bg-black accent-white"
            />
            {label}
          </label>
        ))}
      </div>

      <div className="flex gap-3">
        <button
          type="submit"
          disabled={saving}
          className="rounded-full bg-white px-6 py-3 text-sm font-bold uppercase tracking-wide text-black disabled:opacity-60"
        >
          {saving ? "Saving..." : "Save Product"}
        </button>
        <button
          type="button"
          onClick={() => router.push("/admin/products")}
          className="rounded-full border border-line px-6 py-3 text-sm font-medium text-white hover:border-white"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}
