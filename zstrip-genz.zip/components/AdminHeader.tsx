"use client";

import { Menu } from "lucide-react";

export default function AdminHeader({ onMenuClick }: { onMenuClick: () => void }) {
  return (
    <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-line bg-black/90 px-4 py-3 backdrop-blur md:hidden">
      <button
        onClick={onMenuClick}
        aria-label="Open admin menu"
        className="flex h-9 w-9 items-center justify-center rounded-lg border border-line"
      >
        <Menu className="h-4 w-4" aria-hidden />
      </button>
      <p className="text-sm font-bold tracking-tightest">ZSTRIP GENZ Admin</p>
    </header>
  );
}
