"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import ConfirmDialog from "./ConfirmDialog";

export default function DeleteProductButton({ productId, productName }: { productId: string; productName: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  async function handleDelete() {
    setDeleting(true);
    try {
      const res = await fetch(`/api/admin/products/${productId}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? "Failed to delete product.");
        setDeleting(false);
        setOpen(false);
        return;
      }
      toast.success("Product deleted");
      router.push("/admin/products");
      router.refresh();
    } catch {
      toast.error("Something went wrong deleting the product.");
      setDeleting(false);
    }
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="flex items-center gap-2 rounded-full border border-line px-4 py-2 text-sm font-medium text-white hover:border-white"
      >
        <Trash2 className="h-4 w-4" aria-hidden />
        Delete Product
      </button>
      <ConfirmDialog
        open={open}
        title="Delete Product?"
        description={`This action cannot be undone. "${productName}" will be permanently removed unless it has existing order history, in which case disable it instead.`}
        confirmLabel={deleting ? "Deleting..." : "Delete Product"}
        onConfirm={handleDelete}
        onCancel={() => setOpen(false)}
      />
    </>
  );
}
