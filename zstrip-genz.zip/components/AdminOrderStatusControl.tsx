"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { ORDER_STATUSES, type OrderStatus } from "@/lib/types";
import { ORDER_STATUS_LABEL } from "@/lib/utils";

export default function AdminOrderStatusControl({
  orderId,
  currentStatus,
}: {
  orderId: string;
  currentStatus: OrderStatus;
}) {
  const router = useRouter();
  const [status, setStatus] = useState<OrderStatus>(currentStatus);
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);

  async function handleUpdate() {
    if (status === currentStatus) {
      toast.info("Select a different status to update.");
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/orders/${orderId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderStatus: status, note: note || undefined }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? "Failed to update order status.");
        setSaving(false);
        return;
      }
      toast.success("Order status updated");
      setNote("");
      router.refresh();
    } catch {
      toast.error("Something went wrong updating the order.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-3">
      <div>
        <label htmlFor="status" className="mb-1.5 block text-xs font-medium text-muted">
          Order Status
        </label>
        <select
          id="status"
          value={status}
          onChange={(e) => setStatus(e.target.value as OrderStatus)}
          className="w-full rounded-lg border border-line bg-black px-3.5 py-2.5 text-sm text-white focus:border-white"
        >
          {ORDER_STATUSES.map((s) => (
            <option key={s} value={s}>
              {ORDER_STATUS_LABEL[s]}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label htmlFor="note" className="mb-1.5 block text-xs font-medium text-muted">
          Note (optional — e.g. tracking number)
        </label>
        <input
          id="note"
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Add a note for this status change"
          className="w-full rounded-lg border border-line bg-black px-3.5 py-2.5 text-sm text-white placeholder:text-muted focus:border-white"
        />
      </div>
      <button
        onClick={handleUpdate}
        disabled={saving}
        className="w-full rounded-full bg-white py-3 text-sm font-bold uppercase tracking-wide text-black disabled:opacity-60"
      >
        {saving ? "Updating..." : "Update Status"}
      </button>
      {status === "REFUNDED" && (
        <p className="text-xs text-muted">
          Marking as Refunded only updates the order record — it does not trigger a real Stripe refund.
        </p>
      )}
    </div>
  );
}
