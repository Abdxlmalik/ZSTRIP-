import { Check } from "lucide-react";
import { ACTIVE_TIMELINE, TERMINAL_NEGATIVE, type OrderStatus } from "@/lib/types";
import { ORDER_STATUS_LABEL, cn } from "@/lib/utils";

export default function OrderTimeline({ status }: { status: OrderStatus }) {
  if (TERMINAL_NEGATIVE.includes(status)) {
    return (
      <div className="rounded-xl border border-line bg-surface px-5 py-6 text-center">
        <p className="text-sm font-bold uppercase tracking-wide text-white">
          This order was {ORDER_STATUS_LABEL[status].toLowerCase()}.
        </p>
        <p className="mt-1 text-xs text-muted">Contact support if you have questions about this order.</p>
      </div>
    );
  }

  const currentIndex = ACTIVE_TIMELINE.indexOf(status);

  return (
    <ol className="flex flex-col gap-0 sm:flex-row sm:items-start">
      {ACTIVE_TIMELINE.map((step, i) => {
        const done = i <= currentIndex;
        const isLast = i === ACTIVE_TIMELINE.length - 1;
        return (
          <li key={step} className="flex flex-1 items-start gap-3 sm:flex-col sm:items-center sm:gap-2">
            <div className="flex items-center sm:w-full">
              <span
                className={cn(
                  "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 text-xs font-bold",
                  done ? "border-white bg-white text-black" : "border-line text-muted"
                )}
                aria-hidden
              >
                {done ? <Check className="h-4 w-4" /> : i + 1}
              </span>
              {!isLast && (
                <span
                  className={cn(
                    "hidden h-0.5 flex-1 sm:block",
                    i < currentIndex ? "bg-white" : "bg-line"
                  )}
                  aria-hidden
                />
              )}
            </div>
            <p className={cn("text-xs font-medium sm:text-center", done ? "text-white" : "text-muted")}>
              {ORDER_STATUS_LABEL[step]}
            </p>
            {!isLast && <span className="ml-4 h-6 w-0.5 bg-line sm:hidden" aria-hidden />}
          </li>
        );
      })}
    </ol>
  );
}
