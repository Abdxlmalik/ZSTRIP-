interface MarqueeLoopProps {
  items: string[];
}

/**
 * A continuous horizontal text loop used as a bold graphic section on the
 * home page. Built as a lightweight CSS-driven equivalent since the React
 * Bits `CurvedLoop` source referenced in the brief wasn't actually available
 * in this project — this keeps the same intent (a big, slowly-moving strip
 * of brand phrases) without inventing code we don't have.
 */
export default function MarqueeLoop({ items }: MarqueeLoopProps) {
  const track = [...items, ...items];

  return (
    <div
      className="relative overflow-hidden border-y border-line bg-surface py-6 [mask-image:linear-gradient(90deg,transparent,black_10%,black_90%,transparent)]"
      aria-hidden="true"
    >
      <div className="flex w-max animate-marquee gap-8 whitespace-nowrap motion-reduce:animate-none">
        {track.map((item, i) => (
          <span
            key={i}
            className="text-3xl font-extrabold uppercase tracking-tightest text-transparent [-webkit-text-stroke:1px_#ffffff] sm:text-5xl"
          >
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}
