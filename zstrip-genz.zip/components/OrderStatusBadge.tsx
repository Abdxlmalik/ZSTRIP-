import { CheckCircle2, Clock, Package, RotateCcw, Truck, XCircle } from "lucide-react";
import { ORDER_STATUS_LABEL, ORDER_STATUS_STYLE, cn } from "@/lib/utils";
import type { OrderStatus } from "@/lib/types";

const ICONS: Record<OrderStatus, typeof Clock> = {
  PENDING: Clock,
  CONFIRMED: CheckCircle2,
  PROCESSING: Package,
  SHIPPED: Truck,
  DELIVERED: CheckCircle2,
  CANCELLED: XCircle,
  RETURNED: RotateCcw,
  REFUNDED: RotateCcw,
};

export default function OrderStatusBadge({ status }: { status: OrderStatus }) {
  const Icon = ICONS[status];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-semibold",
        ORDER_STATUS_STYLE[status]
      )}
    >
      <Icon className="h-3.5 w-3.5" aria-hidden />
      {ORDER_STATUS_LABEL[status]}
    </span>
  );
}
