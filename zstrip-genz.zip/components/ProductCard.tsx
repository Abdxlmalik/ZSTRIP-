"use client";

import Image from "next/image";
import Link from "next/link";
import { toast } from "sonner";
import { formatPrice } from "@/lib/utils";
import { useCartStore } from "@/lib/cart-store";
import type { ProductDTO } from "@/lib/types";

export default function ProductCard({ product }: { product: ProductDTO }) {
  const addLine = useCartStore((s) => s.addLine);
  const secondaryImage = product.images[1] ?? product.images[0];
  const outOfStock = product.stock <= 0;

  function quickAdd(e: React.MouseEvent) {
    e.preventDefault();
    if (outOfStock) return;
    const size = product.sizes[0] ?? "One Size";
    addLine({
      productId: product.id,
      slug: product.slug,
      name: product.name,
      image: product.images[0],
      price: product.price,
      size,
      color: product.colors[0] ?? null,
      quantity: 1,
      maxStock: product.stock,
    });
    toast.success(`Added to cart — ${size}`);
  }

  return (
    <Link href={`/products/${product.slug}`} className="group block">
      <div className="relative aspect-[4/5] overflow-hidden rounded-xl bg-surface">
        <Image
          src={product.images[0]}
          alt={product.name}
          fill
          sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
          className="object-cover transition-opacity duration-500 group-hover:opacity-0"
        />
        <Image
          src={secondaryImage}
          alt=""
          fill
          aria-hidden
          sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
          className="object-cover opacity-0 transition-[opacity,transform] duration-500 group-hover:scale-105 group-hover:opacity-100"
        />

        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {product.isNew && (
            <span className="rounded-full bg-white px-2.5 py-1 text-[11px] font-bold text-black">NEW</span>
          )}
          {product.isSale && product.compareAtPrice && (
            <span className="rounded-full border border-white bg-black/70 px-2.5 py-1 text-[11px] font-bold text-white backdrop-blur">
              SALE
            </span>
          )}
        </div>

        {outOfStock && (
          <div className="absolute inset-x-0 bottom-0 bg-black/80 py-2 text-center text-xs font-semibold uppercase tracking-wide text-muted">
            Out of stock
          </div>
        )}

        {!outOfStock && (
          <button
            onClick={quickAdd}
            className="absolute inset-x-3 bottom-3 translate-y-3 rounded-full bg-white py-2.5 text-xs font-bold uppercase tracking-wide text-black opacity-0 transition-all duration-300 group-hover:translate-y-0 group-hover:opacity-100 sm:opacity-0"
          >
            Add to Cart
          </button>
        )}
      </div>

      <div className="mt-3 flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate text-sm font-medium text-white">{product.name}</p>
          <p className="text-xs text-muted">{product.category}</p>
        </div>
        <div className="shrink-0 text-right">
          <p className="text-sm font-semibold text-white">{formatPrice(product.price)}</p>
          {product.compareAtPrice && (
            <p className="text-xs text-muted line-through">{formatPrice(product.compareAtPrice)}</p>
          )}
        </div>
      </div>
    </Link>
  );
}
