"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { useCartStore, cartSubtotal } from "@/lib/cart-store";
import { formatPrice } from "@/lib/utils";
import QuantitySelector from "./QuantitySelector";

export default function CartDrawer() {
  const [mounted, setMounted] = useState(false);
  const isOpen = useCartStore((s) => s.isDrawerOpen);
  const closeDrawer = useCartStore((s) => s.closeDrawer);
  const lines = useCartStore((s) => s.lines);
  const updateQuantity = useCartStore((s) => s.updateQuantity);
  const removeLine = useCartStore((s) => s.removeLine);

  useEffect(() => setMounted(true), []);
  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  if (!mounted) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            className="fixed inset-0 z-[90] bg-black/70 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeDrawer}
          />
          <motion.aside
            role="dialog"
            aria-label="Shopping cart"
            aria-modal="true"
            className="fixed right-0 top-0 z-[91] flex h-full w-full max-w-md flex-col border-l border-line bg-black"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "tween", duration: 0.3, ease: "easeOut" }}
          >
            <div className="flex items-center justify-between border-b border-line px-5 py-4">
              <h2 className="text-base font-bold">Your Cart</h2>
              <button
                onClick={closeDrawer}
                aria-label="Close cart"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-line hover:border-white"
              >
                <X className="h-4 w-4" aria-hidden />
              </button>
            </div>

            {lines.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center gap-4 px-6 text-center">
                <p className="text-sm font-semibold uppercase tracking-wide text-muted">
                  Your cart is empty.
                </p>
                <Link
                  href="/products"
                  onClick={closeDrawer}
                  className="rounded-full bg-white px-5 py-2.5 text-sm font-bold text-black"
                >
                  Continue Shopping
                </Link>
              </div>
            ) : (
              <>
                <div className="thin-scroll flex-1 overflow-y-auto px-5 py-4">
                  <ul className="space-y-5">
                    {lines.map((line) => (
                      <li key={`${line.productId}-${line.size}-${line.color}`} className="flex gap-3">
                        <div className="relative h-20 w-16 shrink-0 overflow-hidden rounded-lg bg-surface">
                          <Image src={line.image} alt={line.name} fill className="object-cover" sizes="64px" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-medium text-white">{line.name}</p>
                          <p className="text-xs text-muted">
                            {line.size}
                            {line.color ? ` · ${line.color}` : ""}
                          </p>
                          <div className="mt-2 flex items-center justify-between">
                            <QuantitySelector
                              size="sm"
                              value={line.quantity}
                              max={line.maxStock}
                              onChange={(q) => updateQuantity(line.productId, line.size, line.color, q)}
                            />
                            <p className="text-sm font-semibold text-white">
                              {formatPrice(line.price * line.quantity)}
                            </p>
                          </div>
                        </div>
                        <button
                          onClick={() => removeLine(line.productId, line.size, line.color)}
                          aria-label={`Remove ${line.name} from cart`}
                          className="self-start text-muted hover:text-white"
                        >
                          <X className="h-4 w-4" aria-hidden />
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="border-t border-line px-5 py-4">
                  <div className="mb-4 flex items-center justify-between text-sm">
                    <span className="text-muted">Subtotal</span>
                    <span className="font-semibold text-white">{formatPrice(cartSubtotal(lines))}</span>
                  </div>
                  <div className="flex gap-3">
                    <Link
                      href="/cart"
                      onClick={closeDrawer}
                      className="flex-1 rounded-full border border-line py-3 text-center text-sm font-semibold text-white hover:border-white"
                    >
                      View Cart
                    </Link>
                    <Link
                      href="/checkout"
                      onClick={closeDrawer}
                      className="flex-1 rounded-full bg-white py-3 text-center text-sm font-bold text-black"
                    >
                      Checkout
                    </Link>
                  </div>
                </div>
              </>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
