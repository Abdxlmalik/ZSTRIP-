import { PrismaClient } from "@prisma/client";
import products from "../data/products.json";

const prisma = new PrismaClient();

async function main() {
  console.log(`Seeding ${products.length} products...`);

  for (const p of products) {
    await prisma.product.upsert({
      where: { slug: p.slug },
      update: {},
      create: {
        name: p.name,
        slug: p.slug,
        description: p.description,
        price: p.price,
        compareAtPrice: p.compareAtPrice ?? null,
        images: JSON.stringify(p.images),
        category: p.category,
        sizes: JSON.stringify(p.sizes),
        colors: JSON.stringify(p.colors),
        stock: p.stock,
        sku: p.sku,
        material: p.material ?? null,
        fit: p.fit ?? null,
        care: p.care ?? null,
        featured: p.featured,
        isNew: p.isNew,
        isSale: p.isSale,
        published: p.published,
      },
    });
  }

  await prisma.settings.upsert({
    where: { id: 1 },
    update: {},
    create: {
      id: 1,
      storeName: "ZSTRIP Genz",
      currency: "INR",
      lowStockThreshold: 10,
      storeEmail: "support@zstripgenz.example.com",
    },
  });

  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
