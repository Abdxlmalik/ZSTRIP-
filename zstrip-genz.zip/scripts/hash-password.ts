/**
 * Usage: npm run hash:password -- "yourpassword"
 * Prints a bcrypt hash to paste into ADMIN_PASSWORD_HASH in .env.local
 */
import bcrypt from "bcryptjs";

const password = process.argv[2];
if (!password) {
  console.error('Usage: npm run hash:password -- "yourpassword"');
  process.exit(1);
}

bcrypt.hash(password, 10).then((hash) => {
  console.log("\nAdd this to your .env.local:\n");
  console.log(`ADMIN_PASSWORD_HASH=${hash}\n`);
});
