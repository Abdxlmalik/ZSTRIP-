"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { X } from "lucide-react";
import { useCartStore } from "@/lib/cart-store";
import { formatPrice } from "@/lib/utils";
import { computeOrderTotals, FREE_SHIPPING_THRESHOLD } from "@/lib/pricing";
import QuantitySelector from "@/components/QuantitySelector";

export default function CartPage() {
  const [mounted, setMounted] = useState(false);
  const lines = useCartStore((s) => s.lines);
  const updateQuantity = useCartStore((s) => s.updateQuantity);
  const removeLine = useCartStore((s) => s.removeLine);

  useEffect(() => setMounted(true), []);

  if (!mounted) {
    return <div className="mx-auto max-w-5xl px-4 py-16" aria-hidden />;
  }

  const { subtotal, shipping, tax, total } = computeOrderTotals(lines);

  if (lines.length === 0) {
    return (
      <div className="mx-auto flex max-w-5xl flex-col items-center px-4 py-24 text-center">
        <h1 className="text-3xl font-extrabold tracking-tightest">Your Cart is Empty.</h1>
        <p className="mt-2 text-sm text-muted">Nothing here yet — go find something worth wearing.</p>
        <Link href="/products" className="mt-8 rounded-full bg-white px-6 py-3 text-sm font-bold text-black">
          Continue Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-extrabold tracking-tightest sm:text-4xl">Your Cart</h1>

      <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_360px]">
        <ul className="divide-y divide-line border-y border-line">
          {lines.map((line) => (
            <li key={`${line.productId}-${line.size}-${line.color}`} className="flex gap-4 py-6">
              <Link href={`/products/${line.slug}`} className="relative h-28 w-24 shrink-0 overflow-hidden rounded-lg bg-surface">
                <Image src={line.image} alt={line.name} fill className="object-cover" sizes="96px" />
              </Link>
              <div className="flex flex-1 flex-col justify-between">
                <div className="flex justify-between gap-3">
                  <div>
                    <Link href={`/products/${line.slug}`} className="text-sm font-semibold text-white hover:underline">
                      {line.name}
                    </Link>
                    <p className="mt-1 text-xs text-muted">
                      Size {line.size}
                      {line.color ? ` · ${line.color}` : ""}
                    </p>
                    <p className="mt-1 text-xs text-muted">{formatPrice(line.price)} each</p>
                  </div>
                  <button
                    onClick={() => removeLine(line.productId, line.size, line.color)}
                    aria-label={`Remove ${line.name}`}
                    className="text-muted hover:text-white"
                  >
                    <X className="h-4 w-4" aria-hidden />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <QuantitySelector
                    size="sm"
                    value={line.quantity}
                    max={line.maxStock}
                    onChange={(q) => updateQuantity(line.productId, line.size, line.color, q)}
                  />
                  <p className="text-sm font-semibold text-white">{formatPrice(line.price * line.quantity)}</p>
                </div>
              </div>
            </li>
          ))}
        </ul>

        <aside className="h-fit rounded-xl border border-line bg-surface p-6">
          <h2 className="text-sm font-bold uppercase tracking-wide text-white">Order Summary</h2>
          <dl className="mt-5 space-y-3 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted">Subtotal</dt>
              <dd className="text-white">{formatPrice(subtotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted">Shipping</dt>
              <dd className="text-white">{shipping === 0 ? "Free" : formatPrice(shipping)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted">Tax (5%)</dt>
              <dd className="text-white">{formatPrice(tax)}</dd>
            </div>
            <div className="flex justify-between border-t border-line pt-3 text-base font-bold">
              <dt>Total</dt>
              <dd>{formatPrice(total)}</dd>
            </div>
          </dl>
          {shipping > 0 && (
            <p className="mt-3 text-xs text-muted">
              Add {formatPrice(FREE_SHIPPING_THRESHOLD - subtotal)} more for free shipping.
            </p>
          )}
          <Link
            href="/checkout"
            className="mt-6 block rounded-full bg-white py-3.5 text-center text-sm font-bold uppercase tracking-wide text-black"
          >
            Proceed to Checkout
          </Link>
          <Link
            href="/products"
            className="mt-3 block rounded-full border border-line py-3.5 text-center text-sm font-medium text-white hover:border-white"
          >
            Continue Shopping
          </Link>
        </aside>
      </div>
    </div>
  );
}
