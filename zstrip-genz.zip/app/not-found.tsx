import Link from "next/link";

export default function NotFound() {
  return (
    <div className="flex min-h-[70vh] flex-col items-center justify-center px-4 text-center">
      <p className="text-sm font-semibold uppercase tracking-widest text-muted">Error 404</p>
      <h1 className="mt-4 text-6xl font-extrabold tracking-tightest sm:text-8xl">LOST THE STRIP.</h1>
      <p className="mt-4 max-w-md text-muted">
        This page doesn&apos;t exist, or it moved. Let&apos;s get you back to something real.
      </p>
      <div className="mt-8 flex flex-wrap justify-center gap-3">
        <Link href="/" className="rounded-full bg-white px-6 py-3 text-sm font-bold text-black">
          Back Home
        </Link>
        <Link
          href="/products"
          className="rounded-full border border-line px-6 py-3 text-sm font-bold text-white hover:border-white"
        >
          Shop All
        </Link>
      </div>
    </div>
  );
}
