import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { formatDate, formatDateTime, formatPrice } from "@/lib/utils";
import type { OrderStatus } from "@/lib/types";
import OrderTimeline from "@/components/OrderTimeline";
import OrderStatusBadge from "@/components/OrderStatusBadge";

export const metadata: Metadata = { title: "Track Order" };

interface OrderPageProps {
  params: { id: string };
  searchParams: { success?: string };
}

export default async function OrderTrackingPage({ params, searchParams }: OrderPageProps) {
  const order = await db.order.findUnique({
    where: { id: params.id },
    include: { items: true },
  });

  if (!order) notFound();

  const status = order.orderStatus as OrderStatus;
  const showConfirmation = searchParams.success === "true" && order.paymentStatus === "PAID";

  const estimatedDelivery = new Date(order.createdAt);
  estimatedDelivery.setDate(estimatedDelivery.getDate() + 6);

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      {showConfirmation && (
        <div className="mb-8 rounded-xl border border-white bg-surface px-6 py-6 text-center">
          <p className="text-xs font-semibold uppercase tracking-widest text-muted">Payment Successful</p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tightest">Order Confirmed</h1>
          <p className="mt-2 text-sm text-muted">
            A confirmation has been sent to {order.customerEmail}. Save your order number below to track it later.
          </p>
        </div>
      )}

      {!showConfirmation && (
        <h1 className="mb-8 text-3xl font-extrabold tracking-tightest sm:text-4xl">Order Tracking</h1>
      )}

      <div className="rounded-xl border border-line bg-surface p-6">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wide text-muted">Order Number</p>
            <p className="mt-1 text-lg font-bold text-white">{order.orderNumber}</p>
            <p className="mt-1 text-xs text-muted">Placed {formatDate(order.createdAt)}</p>
          </div>
          <div className="text-right">
            <OrderStatusBadge status={status} />
            <p className="mt-2 text-xs text-muted">
              Payment: <span className="font-medium text-white">{order.paymentStatus}</span>
            </p>
          </div>
        </div>

        <div className="mt-8">
          <OrderTimeline status={status} />
        </div>

        {status === "PENDING" && order.paymentStatus === "UNPAID" && (
          <p className="mt-4 text-xs text-muted">
            Estimated delivery once shipped: {formatDate(estimatedDelivery)}
          </p>
        )}
        {order.paymentStatus === "PAID" && !["CANCELLED", "RETURNED", "REFUNDED"].includes(status) && (
          <p className="mt-4 text-xs text-muted">Estimated delivery: {formatDate(estimatedDelivery)}</p>
        )}
      </div>

      <div className="mt-8 grid gap-6 sm:grid-cols-2">
        <div className="rounded-xl border border-line p-6">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted">Customer</p>
          <p className="mt-2 text-sm font-medium text-white">{order.customerName}</p>
          <p className="text-sm text-muted">{order.customerEmail}</p>
          {order.customerPhone && <p className="text-sm text-muted">{order.customerPhone}</p>}
        </div>
        <div className="rounded-xl border border-line p-6">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted">Shipping Address</p>
          <p className="mt-2 text-sm text-white">{order.addressLine}</p>
          <p className="text-sm text-muted">
            {order.city}, {order.state} {order.postalCode}
          </p>
          <p className="text-sm text-muted">{order.country}</p>
        </div>
      </div>

      <div className="mt-8 rounded-xl border border-line p-6">
        <p className="mb-4 text-xs font-semibold uppercase tracking-wide text-muted">Items</p>
        <ul className="divide-y divide-line">
          {order.items.map((item) => (
            <li key={item.id} className="flex items-center gap-4 py-4 first:pt-0 last:pb-0">
              <div className="relative h-16 w-14 shrink-0 overflow-hidden rounded-lg bg-black">
                <Image src={item.image} alt={item.name} fill className="object-cover" sizes="56px" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-white">{item.name}</p>
                <p className="text-xs text-muted">
                  {item.size}
                  {item.color ? ` · ${item.color}` : ""} · Qty {item.quantity}
                </p>
              </div>
              <p className="shrink-0 text-sm font-semibold text-white">
                {formatPrice(item.price * item.quantity)}
              </p>
            </li>
          ))}
        </ul>

        <dl className="mt-4 space-y-2 border-t border-line pt-4 text-sm">
          <div className="flex justify-between">
            <dt className="text-muted">Subtotal</dt>
            <dd className="text-white">{formatPrice(order.subtotal)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted">Shipping</dt>
            <dd className="text-white">{order.shipping === 0 ? "Free" : formatPrice(order.shipping)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted">Tax</dt>
            <dd className="text-white">{formatPrice(order.tax)}</dd>
          </div>
          <div className="flex justify-between border-t border-line pt-3 text-base font-bold">
            <dt>Total</dt>
            <dd>{formatPrice(order.total)}</dd>
          </div>
        </dl>
      </div>

      <p className="mt-6 text-center text-xs text-muted">
        Last updated {formatDateTime(order.updatedAt)}
      </p>

      <div className="mt-8 flex justify-center gap-3">
        <Link href="/products" className="rounded-full bg-white px-6 py-3 text-sm font-bold text-black">
          Continue Shopping
        </Link>
        <Link href="/order" className="rounded-full border border-line px-6 py-3 text-sm font-medium text-white hover:border-white">
          Track Another Order
        </Link>
      </div>
    </div>
  );
}
