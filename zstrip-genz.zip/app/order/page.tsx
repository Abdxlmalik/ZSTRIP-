"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";

export default function OrderLookupPage() {
  const router = useRouter();
  const [orderNumber, setOrderNumber] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const params = new URLSearchParams({ orderNumber: orderNumber.trim(), email: email.trim() });
      const res = await fetch(`/api/orders?${params.toString()}`);
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? "No matching order found.");
        return;
      }
      router.push(`/order/${data.id}`);
    } catch {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="mx-auto max-w-md px-4 py-20">
      <h1 className="text-3xl font-extrabold tracking-tightest">Track Order</h1>
      <p className="mt-2 text-sm text-muted">
        Enter your order number and the email used at checkout to see its status.
      </p>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <div>
          <label htmlFor="orderNumber" className="mb-1.5 block text-xs font-medium text-muted">
            Order Number
          </label>
          <input
            id="orderNumber"
            required
            placeholder="ZSG-2026-000001"
            value={orderNumber}
            onChange={(e) => setOrderNumber(e.target.value)}
            className="w-full rounded-lg border border-line bg-surface px-3.5 py-2.5 text-sm text-white placeholder:text-muted focus:border-white"
          />
        </div>
        <div>
          <label htmlFor="email" className="mb-1.5 block text-xs font-medium text-muted">
            Email
          </label>
          <input
            id="email"
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full rounded-lg border border-line bg-surface px-3.5 py-2.5 text-sm text-white placeholder:text-muted focus:border-white"
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-full bg-white py-3.5 text-sm font-bold uppercase tracking-wide text-black disabled:opacity-60"
        >
          {loading ? "Searching..." : "Track Order"}
        </button>
      </form>
    </div>
  );
}
