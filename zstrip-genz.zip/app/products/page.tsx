import { Suspense } from "react";
import type { Metadata } from "next";
import { getProducts, CATEGORIES, type ProductQuery } from "@/lib/products";
import ProductGrid from "@/components/ProductGrid";
import ProductFilters from "@/components/ProductFilters";
import SearchBar from "@/components/SearchBar";
import { SortSelect, MobileFilterDrawer } from "@/components/ProductToolbarExtras";

export const metadata: Metadata = {
  title: "Shop All",
  description: "Browse the full ZSTRIP Genz collection — streetwear built for the next generation.",
};

const ALL_SIZES = ["XS", "S", "M", "L", "XL", "XXL", "28", "30", "32", "34", "36", "One Size"];

interface ProductsPageProps {
  searchParams: {
    q?: string;
    category?: string;
    size?: string;
    minPrice?: string;
    maxPrice?: string;
    inStock?: string;
    sort?: string;
  };
}

const VALID_SORTS: NonNullable<ProductQuery["sort"]>[] = [
  "featured",
  "newest",
  "price-asc",
  "price-desc",
  "name-asc",
];

export default async function ProductsPage({ searchParams }: ProductsPageProps) {
  const requestedSort = searchParams.sort as ProductQuery["sort"] | undefined;
  const sort = VALID_SORTS.includes(requestedSort as NonNullable<ProductQuery["sort"]>)
    ? requestedSort
    : "featured";

  const products = await getProducts({
    q: searchParams.q,
    category: searchParams.category,
    size: searchParams.size,
    minPrice: searchParams.minPrice ? Number(searchParams.minPrice) : undefined,
    maxPrice: searchParams.maxPrice ? Number(searchParams.maxPrice) : undefined,
    inStockOnly: searchParams.inStock === "1",
    sort,
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold tracking-tightest sm:text-4xl">Shop All</h1>
        <p className="mt-2 text-sm text-muted">{products.length} products</p>
      </div>

      <Suspense fallback={null}>
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="sm:max-w-xs sm:flex-1">
            <SearchBar />
          </div>
          <div className="flex items-center gap-3">
            <MobileFilterDrawer categories={CATEGORIES} sizes={ALL_SIZES} />
            <SortSelect />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-10 lg:grid-cols-[220px_1fr]">
          <aside className="hidden lg:block">
            <ProductFilters categories={CATEGORIES} sizes={ALL_SIZES} />
          </aside>
          <ProductGrid products={products} />
        </div>
      </Suspense>
    </div>
  );
}
