import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { Toaster } from "sonner";
import SiteChrome from "@/components/SiteChrome";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_BASE_URL ?? "http://localhost:3000"),
  title: {
    default: "ZSTRIP Genz — Wear The Next.",
    template: "%s — ZSTRIP Genz",
  },
  description:
    "ZSTRIP Genz is a futuristic Gen-Z clothing brand built for people who define their own style.",
  openGraph: {
    title: "ZSTRIP Genz — Wear The Next.",
    description:
      "ZSTRIP Genz is a futuristic Gen-Z clothing brand built for people who define their own style.",
    siteName: "ZSTRIP Genz",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="min-h-screen bg-base font-sans text-ink antialiased">
        <SiteChrome>{children}</SiteChrome>
        <Toaster
          position="bottom-center"
          theme="dark"
          toastOptions={{
            style: {
              background: "#0A0A0A",
              border: "1px solid #27272A",
              color: "#FFFFFF",
            },
          }}
        />
      </body>
    </html>
  );
}
