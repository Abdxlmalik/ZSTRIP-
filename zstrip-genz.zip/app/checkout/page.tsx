"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { useCartStore } from "@/lib/cart-store";
import { formatPrice } from "@/lib/utils";
import { computeOrderTotals } from "@/lib/pricing";

interface FormState {
  fullName: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
}

const INITIAL_FORM: FormState = {
  fullName: "",
  email: "",
  phone: "",
  address: "",
  city: "",
  state: "",
  postalCode: "",
  country: "India",
};

export default function CheckoutPage() {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  const lines = useCartStore((s) => s.lines);
  const [form, setForm] = useState<FormState>(INITIAL_FORM);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (mounted && lines.length === 0) router.replace("/cart");
  }, [mounted, lines.length, router]);

  if (!mounted || lines.length === 0) {
    return <div className="mx-auto max-w-5xl px-4 py-16" aria-hidden />;
  }

  const { subtotal, shipping, tax, total } = computeOrderTotals(lines);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer: form,
          items: lines.map((l) => ({
            productId: l.productId,
            size: l.size,
            color: l.color,
            quantity: l.quantity,
          })),
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        toast.error(data.error ?? "Checkout failed. Please try again.");
        setSubmitting(false);
        return;
      }

      window.location.href = data.url;
    } catch {
      toast.error("Something went wrong reaching the payment server. Please try again.");
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="text-3xl font-extrabold tracking-tightest sm:text-4xl">Checkout</h1>

      <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_380px]">
        <form onSubmit={handleSubmit} className="space-y-8">
          <fieldset className="space-y-4">
            <legend className="text-sm font-bold uppercase tracking-wide text-white">Contact</legend>
            <Field label="Full Name" id="fullName" required>
              <input
                id="fullName"
                required
                value={form.fullName}
                onChange={(e) => update("fullName", e.target.value)}
                className={inputClass}
              />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Email" id="email" required>
                <input
                  id="email"
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => update("email", e.target.value)}
                  className={inputClass}
                />
              </Field>
              <Field label="Phone" id="phone" required>
                <input
                  id="phone"
                  type="tel"
                  required
                  value={form.phone}
                  onChange={(e) => update("phone", e.target.value)}
                  className={inputClass}
                />
              </Field>
            </div>
          </fieldset>

          <fieldset className="space-y-4">
            <legend className="text-sm font-bold uppercase tracking-wide text-white">Shipping Address</legend>
            <Field label="Address" id="address" required>
              <input
                id="address"
                required
                value={form.address}
                onChange={(e) => update("address", e.target.value)}
                className={inputClass}
              />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="City" id="city" required>
                <input
                  id="city"
                  required
                  value={form.city}
                  onChange={(e) => update("city", e.target.value)}
                  className={inputClass}
                />
              </Field>
              <Field label="State" id="state" required>
                <input
                  id="state"
                  required
                  value={form.state}
                  onChange={(e) => update("state", e.target.value)}
                  className={inputClass}
                />
              </Field>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Postal Code" id="postalCode" required>
                <input
                  id="postalCode"
                  required
                  value={form.postalCode}
                  onChange={(e) => update("postalCode", e.target.value)}
                  className={inputClass}
                />
              </Field>
              <Field label="Country" id="country" required>
                <input
                  id="country"
                  required
                  value={form.country}
                  onChange={(e) => update("country", e.target.value)}
                  className={inputClass}
                />
              </Field>
            </div>
          </fieldset>

          <button
            type="submit"
            disabled={submitting}
            className="w-full rounded-full bg-white py-4 text-sm font-bold uppercase tracking-wide text-black transition-transform hover:scale-[1.01] active:scale-95 disabled:cursor-wait disabled:opacity-60"
          >
            {submitting ? "Redirecting to Stripe..." : "Pay Now"}
          </button>
          <p className="text-center text-xs text-muted">
            You&apos;ll be redirected to Stripe&apos;s secure test-mode checkout to complete payment.
          </p>
        </form>

        <aside className="h-fit space-y-6 rounded-xl border border-line bg-surface p-6">
          <h2 className="text-sm font-bold uppercase tracking-wide text-white">Order Summary</h2>
          <ul className="space-y-4">
            {lines.map((line) => (
              <li key={`${line.productId}-${line.size}-${line.color}`} className="flex gap-3">
                <div className="relative h-16 w-14 shrink-0 overflow-hidden rounded-lg bg-black">
                  <Image src={line.image} alt={line.name} fill className="object-cover" sizes="56px" />
                  <span className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-white text-[10px] font-bold text-black">
                    {line.quantity}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-medium text-white">{line.name}</p>
                  <p className="text-xs text-muted">
                    {line.size}
                    {line.color ? ` · ${line.color}` : ""}
                  </p>
                </div>
                <p className="shrink-0 text-xs font-semibold text-white">{formatPrice(line.price * line.quantity)}</p>
              </li>
            ))}
          </ul>
          <dl className="space-y-2 border-t border-line pt-4 text-sm">
            <div className="flex justify-between">
              <dt className="text-muted">Subtotal</dt>
              <dd className="text-white">{formatPrice(subtotal)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted">Shipping</dt>
              <dd className="text-white">{shipping === 0 ? "Free" : formatPrice(shipping)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-muted">Tax</dt>
              <dd className="text-white">{formatPrice(tax)}</dd>
            </div>
            <div className="flex justify-between border-t border-line pt-3 text-base font-bold">
              <dt>Total</dt>
              <dd>{formatPrice(total)}</dd>
            </div>
          </dl>
          <Link href="/cart" className="block text-center text-xs text-muted underline hover:text-white">
            Edit cart
          </Link>
        </aside>
      </div>
    </div>
  );
}

const inputClass =
  "w-full rounded-lg border border-line bg-black px-3.5 py-2.5 text-sm text-white placeholder:text-muted focus:border-white";

function Field({
  label,
  id,
  required,
  children,
}: {
  label: string;
  id: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-1.5 block text-xs font-medium text-muted">
        {label} {required && <span aria-hidden>*</span>}
      </label>
      {children}
    </div>
  );
}
