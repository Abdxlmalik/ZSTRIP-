import Link from "next/link";
import Image from "next/image";
import { DollarSign, ShoppingBag, Package, Users, AlertTriangle } from "lucide-react";
import { getKpiSummary, getRevenueSeries, getBestSellers, getLowStockProducts } from "@/lib/analytics";
import { formatPrice } from "@/lib/utils";
import AnalyticsCard from "@/components/AnalyticsCard";
import RevenueChart from "@/components/RevenueChart";

export const metadata = { title: "Dashboard — Admin" };
export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  const [kpis, series, bestSellers, lowStock] = await Promise.all([
    getKpiSummary(),
    getRevenueSeries(30),
    getBestSellers(5),
    getLowStockProducts(),
  ]);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tightest sm:text-3xl">Dashboard</h1>
        <p className="mt-1 text-sm text-muted">Live figures calculated from your orders and products.</p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <AnalyticsCard label="Total Revenue" value={formatPrice(kpis.totalRevenue)} icon={DollarSign} accent />
        <AnalyticsCard label="Orders" value={String(kpis.ordersCount)} icon={ShoppingBag} />
        <AnalyticsCard label="Products" value={String(kpis.productsCount)} icon={Package} />
        <AnalyticsCard label="Customers" value={String(kpis.customersCount)} icon={Users} />
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <AnalyticsCard label="Today's Revenue" value={formatPrice(kpis.todayRevenue)} />
        <AnalyticsCard label="This Week" value={formatPrice(kpis.weekRevenue)} />
        <AnalyticsCard label="This Month" value={formatPrice(kpis.monthRevenue)} subtext={`${kpis.ordersThisMonth} orders`} />
        <AnalyticsCard label="Avg. Order Value" value={formatPrice(kpis.averageOrderValue)} />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <AnalyticsCard label="Pending" value={String(kpis.pendingOrders)} />
        <AnalyticsCard label="Cancelled" value={String(kpis.cancelledOrders)} />
        <AnalyticsCard label="Returned" value={String(kpis.returnedOrders)} />
      </div>

      <div className="rounded-xl border border-line bg-surface p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-bold uppercase tracking-wide">Revenue — Last 30 Days</h2>
          <Link href="/admin/analytics" className="text-xs font-medium text-muted hover:text-white">
            Full analytics →
          </Link>
        </div>
        <RevenueChart data={series} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-xl border border-line bg-surface p-5">
          <h2 className="mb-4 text-sm font-bold uppercase tracking-wide">Best Selling Products</h2>
          {bestSellers.length === 0 ? (
            <p className="text-sm text-muted">No sales yet.</p>
          ) : (
            <ul className="space-y-4">
              {bestSellers.map((p) => (
                <li key={p.productId} className="flex items-center gap-3">
                  <div className="relative h-12 w-10 shrink-0 overflow-hidden rounded-lg bg-black">
                    <Image src={p.image} alt={p.name} fill className="object-cover" sizes="40px" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-white">{p.name}</p>
                    <p className="text-xs text-muted">{p.unitsSold} sold · {p.stock} in stock</p>
                  </div>
                  <p className="shrink-0 text-sm font-semibold text-white">{formatPrice(p.revenue)}</p>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="rounded-xl border border-line bg-surface p-5">
          <div className="mb-4 flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-muted" aria-hidden />
            <h2 className="text-sm font-bold uppercase tracking-wide">Low Stock</h2>
          </div>
          {lowStock.length === 0 ? (
            <p className="text-sm text-muted">Everything is well stocked.</p>
          ) : (
            <ul className="space-y-3">
              {lowStock.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-white">{p.name}</p>
                    <p className="text-xs text-muted">{p.sku}</p>
                  </div>
                  <span className="shrink-0 rounded-full border border-line px-2.5 py-1 text-xs font-semibold text-white">
                    {p.stock} left
                  </span>
                </li>
              ))}
            </ul>
          )}
          <Link
            href="/admin/products"
            className="mt-5 block rounded-full border border-line py-2.5 text-center text-xs font-semibold text-white hover:border-white"
          >
            Manage Inventory
          </Link>
        </div>
      </div>
    </div>
  );
}
