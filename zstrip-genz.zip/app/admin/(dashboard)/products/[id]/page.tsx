import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { toProductDTO } from "@/lib/utils";
import AdminProductForm from "@/components/AdminProductForm";
import DeleteProductButton from "@/components/DeleteProductButton";

export const metadata = { title: "Edit Product — Admin" };

export default async function EditProductPage({ params }: { params: { id: string } }) {
  const product = await db.product.findUnique({ where: { id: params.id } });
  if (!product) notFound();

  const dto = toProductDTO(product);

  return (
    <div className="max-w-3xl">
      <div className="mb-6 flex items-center justify-between gap-4">
        <h1 className="text-2xl font-extrabold tracking-tightest">Edit Product</h1>
        <DeleteProductButton productId={dto.id} productName={dto.name} />
      </div>
      <AdminProductForm product={dto} />
    </div>
  );
}
