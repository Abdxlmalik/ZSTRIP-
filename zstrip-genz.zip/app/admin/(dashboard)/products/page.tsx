"use client";

import { useEffect, useState, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import { toast } from "sonner";
import { Search, Plus, Pencil, Trash2, Eye, EyeOff } from "lucide-react";
import { CATEGORIES } from "@/lib/products";
import { formatPrice, formatDate, cn } from "@/lib/utils";
import ConfirmDialog from "@/components/ConfirmDialog";
import type { ProductDTO } from "@/lib/types";

export default function AdminProductsPage() {
  const [products, setProducts] = useState<ProductDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("");
  const [status, setStatus] = useState("");
  const [stock, setStock] = useState("");
  const [pendingDelete, setPendingDelete] = useState<ProductDTO | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (category) params.set("category", category);
    if (status) params.set("status", status);
    if (stock) params.set("stock", stock);
    try {
      const res = await fetch(`/api/admin/products?${params.toString()}`);
      const data = await res.json();
      setProducts(res.ok ? data : []);
    } finally {
      setLoading(false);
    }
  }, [q, category, status, stock]);

  useEffect(() => {
    const handle = setTimeout(load, 250);
    return () => clearTimeout(handle);
  }, [load]);

  async function togglePublished(product: ProductDTO) {
    const res = await fetch(`/api/admin/products/${product.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ published: !product.published }),
    });
    if (!res.ok) {
      toast.error("Failed to update product status.");
      return;
    }
    toast.success(product.published ? "Product disabled" : "Product enabled");
    load();
  }

  async function confirmDelete() {
    if (!pendingDelete) return;
    const res = await fetch(`/api/admin/products/${pendingDelete.id}`, { method: "DELETE" });
    const data = await res.json();
    if (!res.ok) {
      toast.error(data.error ?? "Failed to delete product.");
      setPendingDelete(null);
      return;
    }
    toast.success("Product deleted");
    setPendingDelete(null);
    load();
  }

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-2xl font-extrabold tracking-tightest">Products</h1>
        <Link
          href="/admin/products/new"
          className="flex items-center gap-2 rounded-full bg-white px-4 py-2.5 text-sm font-bold text-black"
        >
          <Plus className="h-4 w-4" aria-hidden />
          Add Product
        </Link>
      </div>

      <div className="mb-5 flex flex-wrap gap-3">
        <div className="relative min-w-[200px] flex-1">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" aria-hidden />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search name, SKU, category..."
            className="w-full rounded-full border border-line bg-surface py-2.5 pl-10 pr-4 text-sm text-white placeholder:text-muted focus:border-white"
          />
        </div>
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="rounded-full border border-line bg-surface px-4 py-2.5 text-sm text-white"
        >
          <option value="">All Categories</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="rounded-full border border-line bg-surface px-4 py-2.5 text-sm text-white"
        >
          <option value="">All Status</option>
          <option value="published">Published</option>
          <option value="unpublished">Disabled</option>
        </select>
        <select
          value={stock}
          onChange={(e) => setStock(e.target.value)}
          className="rounded-full border border-line bg-surface px-4 py-2.5 text-sm text-white"
        >
          <option value="">All Stock</option>
          <option value="low">Low Stock</option>
          <option value="out">Out of Stock</option>
        </select>
      </div>

      <div className="overflow-x-auto rounded-xl border border-line thin-scroll">
        <table className="w-full min-w-[860px] text-left text-sm">
          <thead className="border-b border-line bg-surface text-xs uppercase tracking-wide text-muted">
            <tr>
              <th className="px-4 py-3 font-medium">Image</th>
              <th className="px-4 py-3 font-medium">Product</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium">Price</th>
              <th className="px-4 py-3 font-medium">Stock</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Created</th>
              <th className="px-4 py-3 font-medium text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {loading ? (
              <tr>
                <td colSpan={8} className="px-4 py-10 text-center text-muted">
                  Loading products...
                </td>
              </tr>
            ) : products.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-4 py-10 text-center text-muted">
                  No products match those filters.
                </td>
              </tr>
            ) : (
              products.map((p) => (
                <tr key={p.id} className="hover:bg-surface/60">
                  <td className="px-4 py-3">
                    <div className="relative h-12 w-10 overflow-hidden rounded-lg bg-surface">
                      <Image src={p.images[0]} alt={p.name} fill className="object-cover" sizes="40px" />
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <p className="font-medium text-white">{p.name}</p>
                    <p className="text-xs text-muted">{p.sku}</p>
                  </td>
                  <td className="px-4 py-3 text-muted">{p.category}</td>
                  <td className="px-4 py-3">
                    <p className="text-white">{formatPrice(p.price)}</p>
                    {p.compareAtPrice && <p className="text-xs text-muted line-through">{formatPrice(p.compareAtPrice)}</p>}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={cn(
                        "rounded-full border px-2.5 py-1 text-xs font-semibold",
                        p.stock === 0
                          ? "border-line text-muted"
                          : p.stock <= 10
                            ? "border-white text-white"
                            : "border-line text-white"
                      )}
                    >
                      {p.stock}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={cn(
                        "rounded-full px-2.5 py-1 text-xs font-semibold",
                        p.published ? "bg-white text-black" : "border border-line text-muted"
                      )}
                    >
                      {p.published ? "Published" : "Disabled"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-muted">{formatDate(p.createdAt)}</td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => togglePublished(p)}
                        title={p.published ? "Disable" : "Enable"}
                        className="flex h-8 w-8 items-center justify-center rounded-lg border border-line hover:border-white"
                      >
                        {p.published ? <EyeOff className="h-3.5 w-3.5" aria-hidden /> : <Eye className="h-3.5 w-3.5" aria-hidden />}
                      </button>
                      <Link
                        href={`/admin/products/${p.id}`}
                        title="Edit"
                        className="flex h-8 w-8 items-center justify-center rounded-lg border border-line hover:border-white"
                      >
                        <Pencil className="h-3.5 w-3.5" aria-hidden />
                      </Link>
                      <button
                        onClick={() => setPendingDelete(p)}
                        title="Delete"
                        className="flex h-8 w-8 items-center justify-center rounded-lg border border-line hover:border-white"
                      >
                        <Trash2 className="h-3.5 w-3.5" aria-hidden />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <ConfirmDialog
        open={Boolean(pendingDelete)}
        title="Delete Product?"
        description={`This action cannot be undone. "${pendingDelete?.name}" will be permanently removed unless it has existing order history.`}
        confirmLabel="Delete Product"
        onConfirm={confirmDelete}
        onCancel={() => setPendingDelete(null)}
      />
    </div>
  );
}
