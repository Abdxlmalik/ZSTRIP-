import AdminProductForm from "@/components/AdminProductForm";

export const metadata = { title: "Add Product — Admin" };

export default function NewProductPage() {
  return (
    <div className="max-w-3xl">
      <h1 className="mb-6 text-2xl font-extrabold tracking-tightest">Add Product</h1>
      <AdminProductForm />
    </div>
  );
}
