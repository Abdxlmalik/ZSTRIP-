import AdminShell from "@/components/AdminShell";

export default function AdminDashboardLayout({ children }: { children: React.ReactNode }) {
  // Auth is already enforced by middleware.ts for everything under /admin
  // (except /admin/login), so this layout only needs to render the chrome.
  return <AdminShell>{children}</AdminShell>;
}
