import Image from "next/image";
import { notFound } from "next/navigation";
import { db } from "@/lib/db";
import { formatDateTime, formatPrice } from "@/lib/utils";
import type { OrderStatus } from "@/lib/types";
import OrderStatusBadge from "@/components/OrderStatusBadge";
import AdminOrderStatusControl from "@/components/AdminOrderStatusControl";

export const metadata = { title: "Order Detail — Admin" };
export const dynamic = "force-dynamic";

export default async function AdminOrderDetailPage({ params }: { params: { id: string } }) {
  const order = await db.order.findUnique({
    where: { id: params.id },
    include: { items: true, statusHistory: { orderBy: { createdAt: "desc" } } },
  });
  if (!order) notFound();

  return (
    <div className="max-w-5xl">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tightest">{order.orderNumber}</h1>
          <p className="mt-1 text-sm text-muted">Placed {formatDateTime(order.createdAt)}</p>
        </div>
        <OrderStatusBadge status={order.orderStatus as OrderStatus} />
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <div className="space-y-6">
          <div className="rounded-xl border border-line bg-surface p-6">
            <h2 className="mb-4 text-xs font-semibold uppercase tracking-wide text-muted">Customer</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <p className="text-xs text-muted">Name</p>
                <p className="text-sm text-white">{order.customerName}</p>
              </div>
              <div>
                <p className="text-xs text-muted">Email</p>
                <p className="text-sm text-white">{order.customerEmail}</p>
              </div>
              {order.customerPhone && (
                <div>
                  <p className="text-xs text-muted">Phone</p>
                  <p className="text-sm text-white">{order.customerPhone}</p>
                </div>
              )}
              <div>
                <p className="text-xs text-muted">Address</p>
                <p className="text-sm text-white">
                  {order.addressLine}, {order.city}, {order.state} {order.postalCode}, {order.country}
                </p>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-line bg-surface p-6">
            <h2 className="mb-4 text-xs font-semibold uppercase tracking-wide text-muted">Items</h2>
            <ul className="divide-y divide-line">
              {order.items.map((item) => (
                <li key={item.id} className="flex items-center gap-4 py-4 first:pt-0 last:pb-0">
                  <div className="relative h-16 w-14 shrink-0 overflow-hidden rounded-lg bg-black">
                    <Image src={item.image} alt={item.name} fill className="object-cover" sizes="56px" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-white">{item.name}</p>
                    <p className="text-xs text-muted">
                      {item.size}
                      {item.color ? ` · ${item.color}` : ""} · Qty {item.quantity} · {formatPrice(item.price)} each
                    </p>
                  </div>
                  <p className="shrink-0 text-sm font-semibold text-white">{formatPrice(item.price * item.quantity)}</p>
                </li>
              ))}
            </ul>
            <dl className="mt-4 space-y-2 border-t border-line pt-4 text-sm">
              <div className="flex justify-between">
                <dt className="text-muted">Subtotal</dt>
                <dd className="text-white">{formatPrice(order.subtotal)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted">Shipping</dt>
                <dd className="text-white">{formatPrice(order.shipping)}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-muted">Tax</dt>
                <dd className="text-white">{formatPrice(order.tax)}</dd>
              </div>
              <div className="flex justify-between border-t border-line pt-3 text-base font-bold text-white">
                <dt>Total</dt>
                <dd>{formatPrice(order.total)}</dd>
              </div>
            </dl>
          </div>

          <div className="rounded-xl border border-line bg-surface p-6">
            <h2 className="mb-4 text-xs font-semibold uppercase tracking-wide text-muted">Payment</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <p className="text-xs text-muted">Payment Status</p>
                <p className="text-sm text-white">{order.paymentStatus}</p>
              </div>
              <div>
                <p className="text-xs text-muted">Stripe Session</p>
                <p className="truncate text-sm text-white">{order.stripeSessionId ?? "—"}</p>
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-line bg-surface p-6">
            <h2 className="mb-4 text-xs font-semibold uppercase tracking-wide text-muted">Status History</h2>
            <ul className="space-y-4">
              {order.statusHistory.map((h) => (
                <li key={h.id} className="border-l-2 border-line pl-4">
                  <p className="text-sm text-white">
                    {h.fromStatus ? `${h.fromStatus} → ${h.toStatus}` : `Created as ${h.toStatus}`}
                  </p>
                  {h.note && <p className="text-xs text-muted">{h.note}</p>}
                  <p className="text-xs text-muted">{formatDateTime(h.createdAt)}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="h-fit rounded-xl border border-line bg-surface p-6">
          <h2 className="mb-4 text-xs font-semibold uppercase tracking-wide text-muted">Update Fulfillment</h2>
          <AdminOrderStatusControl orderId={order.id} currentStatus={order.orderStatus as OrderStatus} />
        </div>
      </div>
    </div>
  );
}
