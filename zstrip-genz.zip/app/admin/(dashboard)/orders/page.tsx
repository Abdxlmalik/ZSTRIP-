"use client";

import { useCallback, useEffect, useState } from "react";
import { Search } from "lucide-react";
import { ORDER_STATUSES } from "@/lib/types";
import { ORDER_STATUS_LABEL, cn } from "@/lib/utils";
import AdminOrderTable, { type AdminOrderRow } from "@/components/AdminOrderTable";

const TABS = ["ALL", ...ORDER_STATUSES] as const;

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<AdminOrderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<(typeof TABS)[number]>("ALL");
  const [q, setQ] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (tab !== "ALL") params.set("status", tab);
    if (q) params.set("q", q);
    try {
      const res = await fetch(`/api/admin/orders?${params.toString()}`);
      const data = await res.json();
      setOrders(res.ok ? data : []);
    } finally {
      setLoading(false);
    }
  }, [tab, q]);

  useEffect(() => {
    const handle = setTimeout(load, 250);
    return () => clearTimeout(handle);
  }, [load]);

  return (
    <div>
      <h1 className="mb-6 text-2xl font-extrabold tracking-tightest">Orders</h1>

      <div className="mb-5 flex flex-wrap gap-2">
        {TABS.map((status) => (
          <button
            key={status}
            onClick={() => setTab(status)}
            className={cn(
              "rounded-full border px-3.5 py-1.5 text-xs font-semibold transition-colors",
              tab === status ? "border-white bg-white text-black" : "border-line text-muted hover:text-white"
            )}
          >
            {status === "ALL" ? "All" : ORDER_STATUS_LABEL[status]}
          </button>
        ))}
      </div>

      <div className="relative mb-5 max-w-sm">
        <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" aria-hidden />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search order ID, customer, email..."
          className="w-full rounded-full border border-line bg-surface py-2.5 pl-10 pr-4 text-sm text-white placeholder:text-muted focus:border-white"
        />
      </div>

      {loading ? (
        <div className="rounded-xl border border-line px-4 py-10 text-center text-sm text-muted">Loading orders...</div>
      ) : (
        <AdminOrderTable orders={orders} />
      )}
    </div>
  );
}
