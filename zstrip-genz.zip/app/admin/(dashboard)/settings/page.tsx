import { db } from "@/lib/db";
import AdminSettingsForm from "@/components/AdminSettingsForm";

export const metadata = { title: "Settings — Admin" };
export const dynamic = "force-dynamic";

export default async function AdminSettingsPage() {
  const settings = await db.settings.upsert({
    where: { id: 1 },
    update: {},
    create: { id: 1 },
  });

  return (
    <div>
      <h1 className="mb-6 text-2xl font-extrabold tracking-tightest">Settings</h1>
      <AdminSettingsForm
        initial={{
          storeName: settings.storeName,
          currency: settings.currency,
          lowStockThreshold: settings.lowStockThreshold,
          storeEmail: settings.storeEmail,
        }}
      />
    </div>
  );
}
