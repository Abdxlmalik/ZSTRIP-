import { Suspense } from "react";
import { getRevenueSeries, getOrderStatusCounts, getReturnRate, getRefundSummary } from "@/lib/analytics";
import { ORDER_STATUS_LABEL, formatPrice } from "@/lib/utils";
import RevenueChart from "@/components/RevenueChart";
import RangeSelect from "@/components/RangeSelect";
import OrderStatusBadge from "@/components/OrderStatusBadge";
import type { OrderStatus } from "@/lib/types";

export const metadata = { title: "Analytics — Admin" };
export const dynamic = "force-dynamic";

const VALID_RANGES = [7, 30, 90, 180, 365];

export default async function AdminAnalyticsPage({
  searchParams,
}: {
  searchParams: { range?: string };
}) {
  const requested = Number(searchParams.range ?? "30");
  const days = VALID_RANGES.includes(requested) ? requested : 30;

  const [series, statusCounts, returnRate, refunds] = await Promise.all([
    getRevenueSeries(days),
    getOrderStatusCounts(),
    getReturnRate(),
    getRefundSummary(),
  ]);

  const totalRevenue = series.reduce((s, p) => s + p.revenue, 0);
  const totalOrders = series.reduce((s, p) => s + p.orders, 0);
  const completedOrders = statusCounts.DELIVERED + statusCounts.RETURNED + statusCounts.REFUNDED;

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <h1 className="text-2xl font-extrabold tracking-tightest">Analytics</h1>
        <Suspense fallback={null}>
          <RangeSelect />
        </Suspense>
      </div>

      <div className="rounded-xl border border-line bg-surface p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-sm font-bold uppercase tracking-wide">Revenue</h2>
          <p className="text-xs text-muted">
            {formatPrice(totalRevenue)} across {totalOrders} paid orders in this range
          </p>
        </div>
        <RevenueChart data={series} />
      </div>

      <div>
        <h2 className="mb-4 text-sm font-bold uppercase tracking-wide">Order Status</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {(Object.keys(statusCounts) as OrderStatus[]).map((status) => (
            <div key={status} className="rounded-xl border border-line bg-surface p-4">
              <OrderStatusBadge status={status} />
              <p className="mt-3 text-2xl font-extrabold tracking-tightest">{statusCounts[status]}</p>
              <p className="text-xs text-muted">{ORDER_STATUS_LABEL[status]}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-line bg-surface p-5">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted">Return Rate</p>
          <p className="mt-3 text-2xl font-extrabold tracking-tightest">{returnRate}%</p>
          <p className="mt-1 text-xs text-muted">Returned ÷ completed orders ({completedOrders})</p>
        </div>
        <div className="rounded-xl border border-line bg-surface p-5">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted">Refunded Orders</p>
          <p className="mt-3 text-2xl font-extrabold tracking-tightest">{refunds.count}</p>
        </div>
        <div className="rounded-xl border border-line bg-surface p-5">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted">Refunded Amount</p>
          <p className="mt-3 text-2xl font-extrabold tracking-tightest">{formatPrice(refunds.amount)}</p>
        </div>
      </div>

      <p className="text-xs text-muted">
        Refunds shown here reflect orders manually marked "Refunded" from the Orders screen — this build
        does not call Stripe&apos;s refund API automatically.
      </p>
    </div>
  );
}
