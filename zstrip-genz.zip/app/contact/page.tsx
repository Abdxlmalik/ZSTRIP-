"use client";

import { useState } from "react";
import { Mail, Instagram, MessageCircle } from "lucide-react";

export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", message: "" });
  const [sent, setSent] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    // No backend for the initial version, per the brief — this simply
    // confirms receipt in the UI. Wire this to an email/service API route
    // before taking the store live.
    setSent(true);
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-16 sm:px-6 lg:px-8">
      <h1 className="text-4xl font-extrabold tracking-tightest sm:text-5xl">Contact</h1>
      <p className="mt-3 max-w-lg text-sm text-muted">
        Questions about an order, a drop, or a collab? Send it over — we read everything.
      </p>

      <div className="mt-12 grid gap-12 lg:grid-cols-[1fr_320px]">
        {sent ? (
          <div className="rounded-xl border border-white bg-surface px-6 py-10 text-center">
            <h2 className="text-2xl font-extrabold tracking-tightest">Message Received.</h2>
            <p className="mt-2 text-sm text-muted">We&apos;ll get back to you soon.</p>
            <button
              onClick={() => {
                setSent(false);
                setForm({ name: "", email: "", phone: "", message: "" });
              }}
              className="mt-6 rounded-full border border-line px-5 py-2.5 text-sm font-medium text-white hover:border-white"
            >
              Send another message
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label htmlFor="name" className="mb-1.5 block text-xs font-medium text-muted">
                Name
              </label>
              <input
                id="name"
                required
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                className="w-full rounded-lg border border-line bg-surface px-3.5 py-2.5 text-sm text-white placeholder:text-muted focus:border-white"
              />
            </div>
            <div className="grid gap-5 sm:grid-cols-2">
              <div>
                <label htmlFor="email" className="mb-1.5 block text-xs font-medium text-muted">
                  Email
                </label>
                <input
                  id="email"
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))}
                  className="w-full rounded-lg border border-line bg-surface px-3.5 py-2.5 text-sm text-white placeholder:text-muted focus:border-white"
                />
              </div>
              <div>
                <label htmlFor="phone" className="mb-1.5 block text-xs font-medium text-muted">
                  Phone (optional)
                </label>
                <input
                  id="phone"
                  value={form.phone}
                  onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))}
                  className="w-full rounded-lg border border-line bg-surface px-3.5 py-2.5 text-sm text-white placeholder:text-muted focus:border-white"
                />
              </div>
            </div>
            <div>
              <label htmlFor="message" className="mb-1.5 block text-xs font-medium text-muted">
                Message
              </label>
              <textarea
                id="message"
                required
                rows={5}
                value={form.message}
                onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                className="w-full rounded-lg border border-line bg-surface px-3.5 py-2.5 text-sm text-white placeholder:text-muted focus:border-white"
              />
            </div>
            <button
              type="submit"
              className="rounded-full bg-white px-6 py-3 text-sm font-bold uppercase tracking-wide text-black"
            >
              Send Message
            </button>
          </form>
        )}

        <aside className="h-fit space-y-6 rounded-xl border border-line bg-surface p-6">
          <div className="flex items-start gap-3">
            <Mail className="mt-0.5 h-4 w-4 shrink-0 text-muted" aria-hidden />
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-muted">Email</p>
              <p className="mt-1 text-sm text-white">support@zstripgenz.example.com</p>
              <p className="mt-0.5 text-xs text-muted">(placeholder — replace before launch)</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Instagram className="mt-0.5 h-4 w-4 shrink-0 text-muted" aria-hidden />
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-muted">Instagram</p>
              <p className="mt-1 text-sm text-white">@zstripgenz</p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <MessageCircle className="mt-0.5 h-4 w-4 shrink-0 text-muted" aria-hidden />
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-muted">Customer Support</p>
              <p className="mt-1 text-sm text-white">Mon–Fri, 10am–6pm IST</p>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
