import type { Metadata } from "next";
import Image from "next/image";
import { imageUrl } from "@/lib/utils";
import AnimatedSection from "@/components/AnimatedSection";

export const metadata: Metadata = {
  title: "About",
  description: "The story, philosophy, and future of ZSTRIP Genz.",
};

export default function AboutPage() {
  return (
    <div>
      <section className="relative flex h-[60vh] items-end overflow-hidden border-b border-line">
        <Image
          src={imageUrl("zstrip-about-hero", 1800, 1400)}
          alt="ZSTRIP Genz studio"
          fill
          priority
          className="object-cover opacity-60"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />
        <div className="relative mx-auto w-full max-w-5xl px-4 pb-14 sm:px-6 lg:px-8">
          <p className="text-xs font-semibold uppercase tracking-widest text-muted">About ZSTRIP Genz</p>
          <h1 className="mt-3 text-5xl font-extrabold tracking-tightest sm:text-7xl">
            Define your own standard.
          </h1>
        </div>
      </section>

      <div className="mx-auto max-w-3xl px-4 py-20 sm:px-6 lg:px-8">
        <AnimatedSection className="border-t border-line pt-10">
          <h2 className="text-2xl font-extrabold tracking-tightest">Our Story</h2>
          <p className="mt-4 text-sm leading-relaxed text-muted">
            ZSTRIP Genz was created around the idea that fashion is not about following every trend —
            it is about creating your own identity. We started as a small studio experimenting with cut,
            weight, and proportion, and grew into a brand built for a generation that would rather set the
            standard than chase it.
          </p>
        </AnimatedSection>

        <AnimatedSection className="mt-16 border-t border-line pt-10" delay={0.05}>
          <h2 className="text-2xl font-extrabold tracking-tightest">Our Philosophy</h2>
          <p className="mt-4 text-sm leading-relaxed text-muted">
            Clean over cluttered. Considered over disposable. Every piece we make is designed to earn a
            permanent place in your rotation, not a single season. We build slowly, in small runs, so that
            what you&apos;re wearing hasn&apos;t already been worn by everyone else.
          </p>
        </AnimatedSection>

        <AnimatedSection className="mt-16 border-t border-line pt-10" delay={0.1}>
          <h2 className="text-2xl font-extrabold tracking-tightest">What We Make</h2>
          <p className="mt-4 text-sm leading-relaxed text-muted">
            Heavyweight tees, technical outerwear, utility pants, and the accessories that hold it all
            together. Every fabric is chosen first for how it wears in, not just how it photographs on
            day one.
          </p>
        </AnimatedSection>

        <AnimatedSection className="mt-16 border-t border-line pt-10" delay={0.15}>
          <h2 className="text-2xl font-extrabold tracking-tightest">The Future</h2>
          <p className="mt-4 text-sm leading-relaxed text-muted">
            ZSTRIP Genz is still early. What comes next is shaped by the people wearing it now — expect
            more limited drops, more collaboration, and a brand that keeps moving instead of settling
            into a formula.
          </p>
        </AnimatedSection>
      </div>
    </div>
  );
}
