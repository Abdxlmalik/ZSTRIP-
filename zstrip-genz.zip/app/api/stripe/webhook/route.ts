import { NextResponse } from "next/server";
import Stripe from "stripe";
import { db } from "@/lib/db";
import { stripe } from "@/lib/stripe";

export async function POST(request: Request) {
  const signature = request.headers.get("stripe-signature");
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!signature || !webhookSecret) {
    return NextResponse.json({ error: "Missing webhook signature or secret." }, { status: 400 });
  }

  const rawBody = await request.text();

  let event: Stripe.Event;
  try {
    // Signature verification is what proves this request actually came from
    // Stripe — never trust an unverified webhook payload.
    event = stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);
  } catch (err) {
    console.error("Stripe webhook signature verification failed:", err);
    return NextResponse.json({ error: "Invalid signature." }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const orderId = session.metadata?.orderId;
    if (!orderId) {
      console.error("Webhook: checkout.session.completed missing orderId metadata");
      return NextResponse.json({ received: true });
    }

    const order = await db.order.findUnique({ where: { id: orderId }, include: { items: true } });
    if (!order) {
      console.error(`Webhook: order ${orderId} not found`);
      return NextResponse.json({ received: true });
    }

    if (order.paymentStatus !== "PAID") {
      await db.$transaction([
        db.order.update({
          where: { id: orderId },
          data: { paymentStatus: "PAID", orderStatus: "CONFIRMED" },
        }),
        db.orderStatusHistory.create({
          data: {
            orderId,
            fromStatus: order.orderStatus,
            toStatus: "CONFIRMED",
            note: "Payment confirmed via Stripe.",
          },
        }),
        ...order.items.map((item) =>
          db.product.update({
            where: { id: item.productId },
            data: { stock: { decrement: item.quantity } },
          })
        ),
      ]);
    }
  }

  return NextResponse.json({ received: true });
}
