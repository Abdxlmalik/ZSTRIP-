import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// Looking an order up requires BOTH the human-friendly order number and the
// email it was placed with — order numbers are sequential and guessable, so
// this pairing keeps a stranger from browsing other customers' addresses.
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const orderNumber = searchParams.get("orderNumber")?.trim();
  const email = searchParams.get("email")?.trim().toLowerCase();

  if (!orderNumber || !email) {
    return NextResponse.json({ error: "Order number and email are required." }, { status: 400 });
  }

  const order = await db.order.findFirst({
    where: { orderNumber, customerEmail: { equals: email } },
    select: { id: true },
  });

  if (!order) {
    return NextResponse.json({ error: "No matching order found." }, { status: 404 });
  }

  return NextResponse.json({ id: order.id });
}
