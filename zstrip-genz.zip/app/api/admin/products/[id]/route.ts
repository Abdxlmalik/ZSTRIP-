import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { slugify, toProductDTO, isPrismaErrorCode } from "@/lib/utils";

const productUpdateSchema = z.object({
  name: z.string().min(1).max(200).optional(),
  slug: z.string().min(1).max(200).optional(),
  description: z.string().min(1).optional(),
  price: z.number().int().min(0).optional(),
  compareAtPrice: z.number().int().min(0).nullable().optional(),
  images: z.array(z.string().min(1)).min(1).optional(),
  category: z.string().min(1).optional(),
  sizes: z.array(z.string().min(1)).optional(),
  colors: z.array(z.string().min(1)).optional(),
  stock: z.number().int().min(0).optional(),
  sku: z.string().min(1).optional(),
  material: z.string().nullable().optional(),
  fit: z.string().nullable().optional(),
  care: z.string().nullable().optional(),
  featured: z.boolean().optional(),
  isNew: z.boolean().optional(),
  isSale: z.boolean().optional(),
  published: z.boolean().optional(),
});

export async function GET(_request: Request, { params }: { params: { id: string } }) {
  const product = await db.product.findUnique({ where: { id: params.id } });
  if (!product) return NextResponse.json({ error: "Product not found." }, { status: 404 });
  return NextResponse.json(toProductDTO(product));
}

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  const body = await request.json().catch(() => null);
  const parsed = productUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid product data." }, { status: 400 });
  }

  const data = parsed.data;

  try {
    const product = await db.product.update({
      where: { id: params.id },
      data: {
        ...(data.name !== undefined ? { name: data.name } : {}),
        ...(data.slug !== undefined ? { slug: slugify(data.slug) } : {}),
        ...(data.description !== undefined ? { description: data.description } : {}),
        ...(data.price !== undefined ? { price: data.price } : {}),
        ...(data.compareAtPrice !== undefined ? { compareAtPrice: data.compareAtPrice } : {}),
        ...(data.images !== undefined ? { images: JSON.stringify(data.images) } : {}),
        ...(data.category !== undefined ? { category: data.category } : {}),
        ...(data.sizes !== undefined ? { sizes: JSON.stringify(data.sizes) } : {}),
        ...(data.colors !== undefined ? { colors: JSON.stringify(data.colors) } : {}),
        ...(data.stock !== undefined ? { stock: data.stock } : {}),
        ...(data.sku !== undefined ? { sku: data.sku } : {}),
        ...(data.material !== undefined ? { material: data.material } : {}),
        ...(data.fit !== undefined ? { fit: data.fit } : {}),
        ...(data.care !== undefined ? { care: data.care } : {}),
        ...(data.featured !== undefined ? { featured: data.featured } : {}),
        ...(data.isNew !== undefined ? { isNew: data.isNew } : {}),
        ...(data.isSale !== undefined ? { isSale: data.isSale } : {}),
        ...(data.published !== undefined ? { published: data.published } : {}),
      },
    });
    return NextResponse.json(toProductDTO(product));
  } catch (error: unknown) {
    if (isPrismaErrorCode(error, "P2025")) {
      return NextResponse.json({ error: "Product not found." }, { status: 404 });
    }
    if (isPrismaErrorCode(error, "P2002")) {
      return NextResponse.json({ error: "A product with that slug or SKU already exists." }, { status: 409 });
    }
    console.error("Update product error:", error);
    return NextResponse.json({ error: "Failed to update product." }, { status: 500 });
  }
}

export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    await db.product.delete({ where: { id: params.id } });
    return NextResponse.json({ success: true });
  } catch (error: unknown) {
    if (isPrismaErrorCode(error, "P2025")) {
      return NextResponse.json({ error: "Product not found." }, { status: 404 });
    }
    if (isPrismaErrorCode(error, "P2003")) {
      // Product has order history — hard delete would break past orders.
      return NextResponse.json(
        {
          error:
            "This product has order history and can't be permanently deleted. Disable it instead to hide it from the storefront.",
        },
        { status: 409 }
      );
    }
    console.error("Delete product error:", error);
    return NextResponse.json({ error: "Failed to delete product." }, { status: 500 });
  }
}
