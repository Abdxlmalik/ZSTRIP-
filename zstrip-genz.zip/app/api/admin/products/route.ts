import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { slugify, toProductDTO, isPrismaErrorCode } from "@/lib/utils";

const productSchema = z.object({
  name: z.string().min(1).max(200),
  slug: z.string().min(1).max(200).optional(),
  description: z.string().min(1),
  price: z.number().int().min(0),
  compareAtPrice: z.number().int().min(0).nullable().optional(),
  images: z.array(z.string().min(1)).min(1),
  category: z.string().min(1),
  sizes: z.array(z.string().min(1)),
  colors: z.array(z.string().min(1)),
  stock: z.number().int().min(0),
  sku: z.string().min(1),
  material: z.string().nullable().optional(),
  fit: z.string().nullable().optional(),
  care: z.string().nullable().optional(),
  featured: z.boolean().optional(),
  isNew: z.boolean().optional(),
  isSale: z.boolean().optional(),
  published: z.boolean().optional(),
});

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const q = searchParams.get("q")?.trim();
  const category = searchParams.get("category")?.trim();
  const status = searchParams.get("status"); // "published" | "unpublished"
  const stock = searchParams.get("stock"); // "low" | "out"

  const products = await db.product.findMany({
    where: {
      ...(q
        ? { OR: [{ name: { contains: q } }, { sku: { contains: q } }, { category: { contains: q } }] }
        : {}),
      ...(category ? { category } : {}),
      ...(status === "published" ? { published: true } : {}),
      ...(status === "unpublished" ? { published: false } : {}),
      ...(stock === "out" ? { stock: 0 } : {}),
      ...(stock === "low" ? { stock: { gt: 0, lte: 10 } } : {}),
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(products.map(toProductDTO));
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = productSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid product data." }, { status: 400 });
  }

  const data = parsed.data;
  const slug = data.slug?.trim() ? slugify(data.slug) : slugify(data.name);

  try {
    const product = await db.product.create({
      data: {
        name: data.name,
        slug,
        description: data.description,
        price: data.price,
        compareAtPrice: data.compareAtPrice ?? null,
        images: JSON.stringify(data.images),
        category: data.category,
        sizes: JSON.stringify(data.sizes),
        colors: JSON.stringify(data.colors),
        stock: data.stock,
        sku: data.sku,
        material: data.material ?? null,
        fit: data.fit ?? null,
        care: data.care ?? null,
        featured: data.featured ?? false,
        isNew: data.isNew ?? false,
        isSale: data.isSale ?? false,
        published: data.published ?? true,
      },
    });
    return NextResponse.json(toProductDTO(product), { status: 201 });
  } catch (error: unknown) {
    if (isPrismaErrorCode(error, "P2002")) {
      return NextResponse.json({ error: "A product with that slug or SKU already exists." }, { status: 409 });
    }
    console.error("Create product error:", error);
    return NextResponse.json({ error: "Failed to create product." }, { status: 500 });
  }
}
