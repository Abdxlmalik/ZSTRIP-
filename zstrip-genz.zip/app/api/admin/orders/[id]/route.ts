import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ORDER_STATUSES } from "@/lib/types";
import { isPrismaErrorCode } from "@/lib/utils";

const statusUpdateSchema = z.object({
  orderStatus: z.enum(ORDER_STATUSES as [string, ...string[]]),
  note: z.string().max(500).optional(),
});

export async function GET(_request: Request, { params }: { params: { id: string } }) {
  const order = await db.order.findUnique({
    where: { id: params.id },
    include: { items: true, statusHistory: { orderBy: { createdAt: "asc" } } },
  });
  if (!order) return NextResponse.json({ error: "Order not found." }, { status: 404 });
  return NextResponse.json(order);
}

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  const body = await request.json().catch(() => null);
  const parsed = statusUpdateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid status." }, { status: 400 });
  }

  const existing = await db.order.findUnique({ where: { id: params.id } });
  if (!existing) {
    return NextResponse.json({ error: "Order not found." }, { status: 404 });
  }

  try {
    const [order] = await db.$transaction([
      db.order.update({
        where: { id: params.id },
        data: {
          orderStatus: parsed.data.orderStatus,
          // Refunds recorded here are a manual admin status change, not an
          // automatic Stripe refund — see README for the real refund flow.
          ...(parsed.data.orderStatus === "REFUNDED" ? { paymentStatus: "REFUNDED" } : {}),
        },
      }),
      db.orderStatusHistory.create({
        data: {
          orderId: params.id,
          fromStatus: existing.orderStatus,
          toStatus: parsed.data.orderStatus,
          note: parsed.data.note ?? null,
        },
      }),
    ]);
    return NextResponse.json(order);
  } catch (error: unknown) {
    if (isPrismaErrorCode(error, "P2025")) {
      return NextResponse.json({ error: "Order not found." }, { status: 404 });
    }
    console.error("Update order status error:", error);
    return NextResponse.json({ error: "Failed to update order status." }, { status: 500 });
  }
}
