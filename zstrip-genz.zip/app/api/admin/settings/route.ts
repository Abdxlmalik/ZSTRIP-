import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";

const settingsSchema = z.object({
  storeName: z.string().min(1).max(120),
  currency: z.string().min(1).max(10),
  lowStockThreshold: z.number().int().min(0).max(1000),
  storeEmail: z.string().email(),
});

export async function GET() {
  const settings = await db.settings.upsert({
    where: { id: 1 },
    update: {},
    create: { id: 1 },
  });
  return NextResponse.json(settings);
}

export async function PATCH(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = settingsSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid settings." }, { status: 400 });
  }

  const settings = await db.settings.upsert({
    where: { id: 1 },
    update: parsed.data,
    create: { id: 1, ...parsed.data },
  });
  return NextResponse.json(settings);
}
