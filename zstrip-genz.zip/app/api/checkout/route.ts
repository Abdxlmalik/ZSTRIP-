import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { stripe } from "@/lib/stripe";
import { computeOrderTotals } from "@/lib/pricing";
import { generateOrderNumber, parseJsonArray, imageUrl } from "@/lib/utils";

const checkoutSchema = z.object({
  customer: z.object({
    fullName: z.string().min(1).max(200),
    email: z.string().email(),
    phone: z.string().min(5).max(30),
    address: z.string().min(1).max(300),
    city: z.string().min(1).max(120),
    state: z.string().min(1).max(120),
    postalCode: z.string().min(1).max(20),
    country: z.string().min(1).max(120),
  }),
  items: z
    .array(
      z.object({
        productId: z.string().min(1),
        size: z.string().min(1),
        color: z.string().nullable(),
        quantity: z.number().int().min(1).max(20),
      })
    )
    .min(1, "Cart is empty"),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = checkoutSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid checkout details. Please check the form and try again." },
        { status: 400 }
      );
    }

    const { customer, items } = parsed.data;

    // Re-fetch every product from the database — never trust prices, names,
    // images, or stock counts sent from the browser.
    const productIds = [...new Set(items.map((i) => i.productId))];
    const products = await db.product.findMany({ where: { id: { in: productIds } } });
    const productMap = new Map(products.map((p) => [p.id, p]));

    const orderItemsData: {
      productId: string;
      name: string;
      image: string;
      size: string;
      color: string | null;
      price: number;
      quantity: number;
    }[] = [];

    for (const item of items) {
      const product = productMap.get(item.productId);
      if (!product || !product.published) {
        return NextResponse.json(
          { error: `One of the items in your cart is no longer available.` },
          { status: 400 }
        );
      }
      if (product.stock < item.quantity) {
        return NextResponse.json(
          { error: `${product.name} only has ${product.stock} left in stock.` },
          { status: 400 }
        );
      }
      const sizes = parseJsonArray(product.sizes);
      if (sizes.length > 0 && !sizes.includes(item.size)) {
        return NextResponse.json({ error: `Invalid size selected for ${product.name}.` }, { status: 400 });
      }

      const images = parseJsonArray(product.images);
      orderItemsData.push({
        productId: product.id,
        name: product.name,
        image: images[0] ? imageUrl(images[0]) : imageUrl(product.slug),
        size: item.size,
        color: item.color,
        price: product.price, // authoritative server-side price
        quantity: item.quantity,
      });
    }

    const totals = computeOrderTotals(orderItemsData);
    const orderCount = await db.order.count();
    const orderNumber = generateOrderNumber(orderCount + 1);

    const baseUrl = process.env.NEXT_PUBLIC_BASE_URL ?? "http://localhost:3000";

    const order = await db.order.create({
      data: {
        orderNumber,
        customerName: customer.fullName,
        customerEmail: customer.email.trim().toLowerCase(),
        customerPhone: customer.phone,
        addressLine: customer.address,
        city: customer.city,
        state: customer.state,
        postalCode: customer.postalCode,
        country: customer.country,
        subtotal: totals.subtotal,
        shipping: totals.shipping,
        tax: totals.tax,
        total: totals.total,
        paymentStatus: "UNPAID",
        orderStatus: "PENDING",
        items: { create: orderItemsData },
        statusHistory: { create: { toStatus: "PENDING", note: "Order created, awaiting payment." } },
      },
    });

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      customer_email: customer.email,
      line_items: [
        ...orderItemsData.map((item) => ({
          quantity: item.quantity,
          price_data: {
            currency: "inr",
            unit_amount: item.price,
            product_data: {
              name: `${item.name} (${item.size}${item.color ? `, ${item.color}` : ""})`,
              images: item.image.startsWith("http") ? [item.image] : undefined,
            },
          },
        })),
        ...(totals.shipping > 0
          ? [
              {
                quantity: 1,
                price_data: {
                  currency: "inr",
                  unit_amount: totals.shipping,
                  product_data: { name: "Shipping" },
                },
              },
            ]
          : []),
        ...(totals.tax > 0
          ? [
              {
                quantity: 1,
                price_data: {
                  currency: "inr",
                  unit_amount: totals.tax,
                  product_data: { name: "Tax" },
                },
              },
            ]
          : []),
      ],
      success_url: `${baseUrl}/order/${order.id}?success=true`,
      cancel_url: `${baseUrl}/checkout?cancelled=true`,
      metadata: { orderId: order.id, orderNumber },
    });

    await db.order.update({
      where: { id: order.id },
      data: { stripeSessionId: session.id },
    });

    return NextResponse.json({ url: session.url });
  } catch (error) {
    console.error("Checkout error:", error);
    return NextResponse.json(
      { error: "We couldn't start checkout. Please try again in a moment." },
      { status: 500 }
    );
  }
}
