import Image from "next/image";
import Link from "next/link";
import { getFeaturedProducts, getNewArrivals, CATEGORIES } from "@/lib/products";
import { imageUrl } from "@/lib/utils";
import ProductGrid from "@/components/ProductGrid";
import MarqueeLoop from "@/components/MarqueeLoop";
import AnimatedSection from "@/components/AnimatedSection";

const CATEGORY_SEEDS: Record<string, string> = {
  "T-Shirts": "zstrip-tee-core-1",
  Hoodies: "zstrip-hoodie-shadow-1",
  Shirts: "zstrip-shirt-essential-1",
  Pants: "zstrip-cargo-utility-1",
  Jackets: "zstrip-jacket-future-1",
  Accessories: "zstrip-cap-signature-1",
};

const WHY_ZSTRIP = [
  { title: "Gen-Z Design", copy: "Cut for how this generation actually moves, not last decade's silhouettes." },
  { title: "Premium Materials", copy: "Heavyweight cottons and technical shells chosen to outlast a season." },
  { title: "Limited Drops", copy: "Small batches. Once a size runs out, it's gone until the next drop." },
  { title: "Built for Everyday", copy: "Designed for the street, the studio, and everything between." },
];

export default async function HomePage() {
  const [featured, newArrivals] = await Promise.all([getFeaturedProducts(8), getNewArrivals(8)]);

  return (
    <>
      {/* HERO */}
      <section className="relative flex min-h-[88vh] items-end overflow-hidden border-b border-line">
        <Image
          src={imageUrl("zstrip-hero-main", 1800, 2000)}
          alt="ZSTRIP Genz — streetwear editorial"
          fill
          priority
          className="object-cover object-top opacity-70"
          sizes="100vw"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/10" />
        <div className="relative mx-auto w-full max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
          <h1 className="text-5xl font-extrabold uppercase leading-[0.95] tracking-tightest text-glow sm:text-7xl lg:text-8xl">
            ZSTRIP
            <br />
            GENZ
          </h1>
          <p className="mt-4 max-w-md text-base text-muted sm:text-lg">
            Wear the next. Futuristic streetwear built for a generation that defines its own standard.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              href="/products"
              className="rounded-full bg-white px-6 py-3 text-sm font-bold uppercase tracking-wide text-black transition-transform hover:scale-[1.03] active:scale-95"
            >
              Shop Now
            </Link>
            <Link
              href="/products?category=Hoodies"
              className="rounded-full border border-white/60 px-6 py-3 text-sm font-bold uppercase tracking-wide text-white transition-colors hover:bg-white/10"
            >
              Explore Collection
            </Link>
          </div>
        </div>
      </section>

      <MarqueeLoop items={["ZSTRIP GENZ", "WEAR THE NEXT", "FUTURE STREETWEAR", "DEFINE YOUR STYLE"]} />

      {/* FEATURED */}
      {featured.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="mb-8 flex items-end justify-between">
            <h2 className="text-3xl font-extrabold tracking-tightest sm:text-4xl">Featured</h2>
            <Link href="/products" className="text-sm font-medium text-muted hover:text-white">
              View all
            </Link>
          </div>
          <ProductGrid products={featured} />
        </section>
      )}

      {/* SHOP BY CATEGORY */}
      <section className="mx-auto max-w-7xl px-4 pb-20 sm:px-6 lg:px-8">
        <h2 className="mb-8 text-3xl font-extrabold tracking-tightest sm:text-4xl">Shop by Category</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {CATEGORIES.map((category) => (
            <Link
              key={category}
              href={`/products?category=${encodeURIComponent(category)}`}
              className="group relative aspect-[3/4] overflow-hidden rounded-xl border border-line"
            >
              <Image
                src={imageUrl(CATEGORY_SEEDS[category] ?? category, 500, 650)}
                alt={category}
                fill
                sizes="(min-width: 1024px) 16vw, 33vw"
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
              <span className="absolute bottom-3 left-3 text-sm font-bold text-white">{category}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* BRAND STATEMENT */}
      <AnimatedSection className="border-y border-line bg-surface py-24">
        <p className="mx-auto max-w-4xl px-4 text-center text-4xl font-extrabold uppercase leading-tight tracking-tightest sm:text-6xl">
          Not made to blend in.
        </p>
      </AnimatedSection>

      {/* NEW ARRIVALS */}
      {newArrivals.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
          <div className="mb-8 flex items-end justify-between">
            <h2 className="text-3xl font-extrabold tracking-tightest sm:text-4xl">New Arrivals</h2>
            <Link href="/products?sort=newest" className="text-sm font-medium text-muted hover:text-white">
              View all
            </Link>
          </div>
          <ProductGrid products={newArrivals} />
        </section>
      )}

      {/* EDITORIAL BANNER */}
      <AnimatedSection className="relative mx-auto my-4 h-[60vh] max-w-7xl overflow-hidden sm:rounded-2xl">
        <Image
          src={imageUrl("zstrip-editorial-banner", 1800, 1200)}
          alt="ZSTRIP Genz editorial"
          fill
          sizes="100vw"
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
        <div className="absolute inset-0 flex items-center justify-center px-6">
          <p className="max-w-2xl text-center text-3xl font-extrabold uppercase tracking-tightest text-white sm:text-5xl">
            Built for the next generation.
          </p>
        </div>
      </AnimatedSection>

      {/* WHY ZSTRIP */}
      <AnimatedSection className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8">
        <h2 className="mb-10 text-3xl font-extrabold tracking-tightest sm:text-4xl">Why ZSTRIP</h2>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {WHY_ZSTRIP.map((item) => (
            <div key={item.title} className="border-t border-line pt-5">
              <p className="text-base font-bold text-white">{item.title}</p>
              <p className="mt-2 text-sm text-muted">{item.copy}</p>
            </div>
          ))}
        </div>
      </AnimatedSection>
    </>
  );
}
